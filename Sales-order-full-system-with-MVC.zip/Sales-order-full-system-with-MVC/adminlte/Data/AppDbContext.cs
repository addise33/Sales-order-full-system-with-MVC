﻿using adminlte.Models;
using adminlte.Models.Orders;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace adminlte.Data
{
    public class AppDbContext: DbContext
    {
        public AppDbContext()
           : base("DefaultConnection")
        {
        }

        public DbSet<Category> Categorys { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<EnterpriseInformation> EnterpriseInformations { get; set; }
        public DbSet<Stock> Stocks { get; set; }
        //public DbSet<SaleOld> SaleOlds { get; set; }
        public DbSet<Sale> Sales { get; set; }
        public DbSet<SalesDetail> SalesDetails { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Credit> Credits { get; set; }
        public DbSet<CreditDetails> CreditDetails { get; set; }
        public DbSet<users> users { get; set; }
        public DbSet<Bill> Bills { get; set; }
        public DbSet<OrderDetails> OrderDetails { get; set; }
        public DbSet<OrderMaster> OrderMasters { get; set; }
        public DbSet<MaintenancendService> maintenancendServices { get; set; }
        public DbSet<ProductList> ProductLists { get; set; }
        public DbSet<Batch> Batchs { get; set; }
    }
}