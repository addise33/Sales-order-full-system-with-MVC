﻿(function () {
    app.controller('HomeCredits', function ($scope, $http, $filter) {
        $scope.Credit = new Object();
        $scope.InvoiceCart = [];
        $scope.Customerinfo = new Object();
        var init = function () {
            GetProducts();
            GetCustomers();
        }; //end of init
        init(); //init is called
        
        function GetProducts() {
            $http.get('/Credits/GetAllProduct')
                .then(function (response) {
                    var data = response.data;
                    $scope.ProductList = data;
                });
        }
        function GetCustomers() {
            $http.get('/Credits/GetAllCustomers')
                .then(function (response) {
                    var data = response.data;
                    $scope.CustomerList = data;
                });
        }
        $scope.AddNewRow = function () {
            $scope.InvoiceCart.push({ ProductId: null, CategoryName: '', UnitPrice: 0, Quantity: 0, LineTotal: 0 ,PaymentMethod: ''});
        }
        
        $scope.SetValueOfProduct = function (productId) {
            var dataObj = $filter('filter')($scope.ProductList, { ProductId: parseInt(productId) })[0];
            const index = $scope.InvoiceCart.findIndex((x) => x.ProductId === productId);
            
            //$scope.InvoiceCart[index].CategoryName = dataObj.CategoryName;
            $scope.InvoiceCart[index].UnitPrice = dataObj.SellingPrice;
            $scope.InvoiceCart[index].QuantityInStore = dataObj.QuantityInStore;
            $scope.InvoiceCart[index].CategoryName = dataObj.CategoryName;
            $scope.InvoiceCart[index].LineTotal = $scope.InvoiceCart[index].UnitPrice * $scope.InvoiceCart[index].Quantity;
        }
        $scope.OnChangeLineTotalSet = function (productId) {
            const index = $scope.InvoiceCart.findIndex((x) => x.ProductId === productId);
            $scope.InvoiceCart[index].LineTotal = $scope.InvoiceCart[index].UnitPrice * $scope.InvoiceCart[index].Quantity;
            //debugger
            //$scope.InvoiceCart[index].QuantityInStore = $scope.InvoiceCart[index].QuantityInStore - $scope.InvoiceCart[index].Quantity;

        }

        $scope.SubTotalCalculation = function () {
            
            $scope.Credit.Subtotal = 0;
            for (var i = 0; i < $scope.InvoiceCart.length; i++) {
                $scope.Credit.Subtotal = $scope.Credit.Subtotal + $scope.InvoiceCart[i].LineTotal;
            }


            var tempTotal = $scope.Credit.Subtotal;
            $scope.Credit.Subtotal = $scope.Credit.Subtotal / 1.15;
            $scope.Credit.VatAmount = tempTotal - $scope.Credit.Subtotal;
            $scope.Credit.TotalAmount = $scope.Credit.Subtotal + $scope.Credit.VatAmount;
        }
        $scope.CalculateDiscount = function () {
            $scope.Credit.DiscountAmount = ($scope.Credit.Subtotal * $scope.Credit.DiscountParcentage) / 100;
        }
        //$scope.CalculateVat = function () {
        //    $scope.Sale.VatAmount = ($scope.Sale.Subtotal * 15) / 100;
        //    $scope.Sale.TotalAmount = ($scope.Sale.Subtotal - 0) + $scope.Sale.VatAmount;
        //   /* $scope.Sale.TotalAmout = $scope.Sale.Subtotal + $scope.Sale.VatAmount;*/
        //}
        $scope.RowDelete = function (index) {
            if (index > -1) {
                $scope.InvoiceCart.splice(index, 1);
            }
            $scope.SubTotalCalculation();
        }
        
        $scope.SaveCredit = function () {
            debugger
            $scope.Credit.CreditNo = $("#CreditNo").val(); 
            $scope.Credit.CreditDate = $("#datepicker2").val(); 
            $scope.Credit.PaymentDue = $("#datepicker").val(); 
            var data = JSON.stringify({
                Credit: $scope.Credit, CreditDetails: $scope.InvoiceCart, Customer: $scope.Customerinfo
            });
            debugger
            return $.ajax({
                
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                type: 'POST',
                url: "/Credits/SaveInvoiceCredit",
                data: data,
                success: function (result) {
                    if (result.IsSuccess == true) {

                        //Reset();
                        alert("Save Success!");
                        window.location = 'Index/';
                    }
                    else {
                        alert("Save failed!");
                    }
                },
                error: function () {
                    alert("Error!")
                }
            });
        }
        $scope.SetValueOfCustomer = function (Id) {
            var dataObj = $filter('filter')($scope.CustomerList, { Id: parseInt(Id) })[0];
        /*    const index = $scope.CustomerList.findIndex((x) => x.Id === Id);*/

            //$scope.InvoiceCart[index].CategoryName = dataObj.CategoryName;
            $scope.Customerinfo.Phone = dataObj.Phone;
            $scope.Customerinfo.TIN = dataObj.TIN;
            $scope.Customerinfo.Address = dataObj.Address;
            $scope.Customerinfo.FirstName = dataObj.FirstName ;
            $scope.Customerinfo.LastName = dataObj.LastName;

        
        }
    });
}).call(angular);