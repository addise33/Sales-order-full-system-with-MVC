﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Credit : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Credits", "ProductId", "dbo.Products");
            DropIndex("dbo.Credits", new[] { "ProductId" });
            CreateTable(
                "dbo.CreditDetails",
                c => new
                    {
                        CreditDetailId = c.Int(nullable: false, identity: true),
                        CreditId = c.Int(nullable: false),
                        ProductId = c.Int(nullable: false),
                        UnitPrice = c.Double(nullable: false),
                        Quantity = c.Int(nullable: false),
                        LineTotal = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.CreditDetailId)
                .ForeignKey("dbo.Credits", t => t.CreditId, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.ProductId, cascadeDelete: true)
                .Index(t => t.CreditId)
                .Index(t => t.ProductId);
            
            AddColumn("dbo.Credits", "CreditNo", c => c.String());
            AddColumn("dbo.Credits", "PaymentMethod", c => c.String());
            AddColumn("dbo.Credits", "RemainingPayment", c => c.Double(nullable: false));
            AlterColumn("dbo.Credits", "CreditDate", c => c.DateTime(nullable: false));
            DropColumn("dbo.Credits", "ProductId");
            DropColumn("dbo.Credits", "Quantity");
            DropColumn("dbo.Credits", "UnitPrice");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Credits", "UnitPrice", c => c.Double(nullable: false));
            AddColumn("dbo.Credits", "Quantity", c => c.Int(nullable: false));
            AddColumn("dbo.Credits", "ProductId", c => c.Int(nullable: false));
            DropForeignKey("dbo.CreditDetails", "ProductId", "dbo.Products");
            DropForeignKey("dbo.CreditDetails", "CreditId", "dbo.Credits");
            DropIndex("dbo.CreditDetails", new[] { "ProductId" });
            DropIndex("dbo.CreditDetails", new[] { "CreditId" });
            AlterColumn("dbo.Credits", "CreditDate", c => c.String());
            DropColumn("dbo.Credits", "RemainingPayment");
            DropColumn("dbo.Credits", "PaymentMethod");
            DropColumn("dbo.Credits", "CreditNo");
            DropTable("dbo.CreditDetails");
            CreateIndex("dbo.Credits", "ProductId");
            AddForeignKey("dbo.Credits", "ProductId", "dbo.Products", "Id", cascadeDelete: true);
        }
    }
}
