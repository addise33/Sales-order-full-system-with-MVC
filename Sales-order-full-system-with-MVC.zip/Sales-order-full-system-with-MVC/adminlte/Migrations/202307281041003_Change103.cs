﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Change103 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.MaintenancendServices",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        DeviceName = c.String(),
                        SerialNumber = c.String(),
                        DeviceDetail = c.String(),
                        MaitenanceDescription = c.String(),
                        CustomerID = c.Int(nullable: false),
                        payment = c.Double(nullable: false),
                        Advancedpayment = c.Double(nullable: false),
                        Remainingpayment = c.Double(nullable: false),
                        ReturnDate = c.DateTime(nullable: false),
                        Remarks = c.String(),
                        UpdatedBy = c.String(),
                        UpdatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Customers", t => t.CustomerID, cascadeDelete: true)
                .Index(t => t.CustomerID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.MaintenancendServices", "CustomerID", "dbo.Customers");
            DropIndex("dbo.MaintenancendServices", new[] { "CustomerID" });
            DropTable("dbo.MaintenancendServices");
        }
    }
}
