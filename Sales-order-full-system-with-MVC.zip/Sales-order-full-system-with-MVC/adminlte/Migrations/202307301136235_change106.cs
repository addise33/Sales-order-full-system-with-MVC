﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class change106 : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Products", name: "ProductList_Id", newName: "ProductListId");
            RenameIndex(table: "dbo.Products", name: "IX_ProductList_Id", newName: "IX_ProductListId");
            DropColumn("dbo.Products", "ProductId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Products", "ProductId", c => c.Int(nullable: false));
            RenameIndex(table: "dbo.Products", name: "IX_ProductListId", newName: "IX_ProductList_Id");
            RenameColumn(table: "dbo.Products", name: "ProductListId", newName: "ProductList_Id");
        }
    }
}
