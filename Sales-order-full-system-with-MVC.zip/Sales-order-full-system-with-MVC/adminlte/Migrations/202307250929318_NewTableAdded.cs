﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NewTableAdded : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Bills",
                c => new
                    {
                        BillId = c.Int(nullable: false, identity: true),
                        BillDate = c.DateTime(nullable: false),
                        OrderId = c.Int(nullable: false),
                        TIN = c.String(),
                        SubTotal = c.Double(nullable: false),
                        TaxPercentage = c.Double(nullable: false),
                        TaxAmount = c.Double(nullable: false),
                        GrandTotal = c.Double(nullable: false),
                        UpdatedBy = c.String(),
                        UpdatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.BillId)
                .ForeignKey("dbo.Orders", t => t.OrderId, cascadeDelete: true)
                .Index(t => t.OrderId);
            
            CreateTable(
                "dbo.Orders",
                c => new
                    {
                        OrderId = c.Int(nullable: false, identity: true),
                        OrderDesc = c.String(),
                        OrderDate = c.DateTime(nullable: false),
                        ExpectedDelvDate = c.DateTime(nullable: false),
                        OrderStatus = c.String(),
                        CustomerId = c.Int(nullable: false),
                        ProductId = c.Int(nullable: false),
                        Quantity = c.Int(nullable: false),
                        UnitPrice = c.Double(nullable: false),
                        TotalAmount = c.Double(nullable: false),
                        AdvancedPayment = c.Double(nullable: false),
                        SubTotal = c.Double(nullable: false),
                        TaxPercentage = c.Double(nullable: false),
                        TaxAmount = c.Double(nullable: false),
                        GrandTotal = c.Double(nullable: false),
                        UpdatedBy = c.String(),
                        UpdatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.OrderId)
                .ForeignKey("dbo.Customers", t => t.CustomerId, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.ProductId, cascadeDelete: true)
                .Index(t => t.CustomerId)
                .Index(t => t.ProductId);
            
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        FirstName = c.String(),
                        LastName = c.String(),
                        TIN = c.String(),
                        Address = c.String(),
                        Phone = c.String(),
                        EmailAddress = c.String(),
                        UpdatedBy = c.String(),
                        UpdatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ProductName = c.String(),
                        SerialNo = c.String(),
                        CategoryId = c.Int(nullable: false),
                        SupplierID = c.Int(nullable: false),
                        UnitPrice = c.Double(nullable: false),
                        QuantityInStore = c.Int(nullable: false),
                        QuantityInOrder = c.Int(nullable: false),
                        TotalPrice = c.Double(nullable: false),
                        UpdateBy = c.String(),
                        UpdateOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Categories", t => t.CategoryId, cascadeDelete: true)
                .ForeignKey("dbo.Suppliers", t => t.SupplierID, cascadeDelete: true)
                .Index(t => t.CategoryId)
                .Index(t => t.SupplierID);
            
            CreateTable(
                "dbo.Categories",
                c => new
                    {
                        CategoryId = c.Int(nullable: false, identity: true),
                        CategoryName = c.String(),
                        Description = c.String(),
                        updated_By = c.String(),
                        updated_On = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.CategoryId);
            
            CreateTable(
                "dbo.Suppliers",
                c => new
                    {
                        SupplierId = c.Int(nullable: false, identity: true),
                        CategoryName = c.String(),
                        SupplierName = c.String(),
                        Adress = c.String(),
                        PhoneNo = c.String(),
                        Email = c.String(),
                        Updated_by = c.String(),
                        Updated_on = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.SupplierId);
            
            CreateTable(
                "dbo.Credits",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CreditDescription = c.String(),
                        CreditDate = c.String(),
                        CustomerID = c.Int(nullable: false),
                        CreditCategory = c.String(),
                        ProductId = c.Int(nullable: false),
                        Quantity = c.Int(nullable: false),
                        UnitPrice = c.Double(nullable: false),
                        TotalAmount = c.Double(nullable: false),
                        AdvancedPayment = c.Double(nullable: false),
                        PaymentDue = c.DateTime(nullable: false),
                        UpdatedBy = c.String(),
                        UpdatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Customers", t => t.CustomerID, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.ProductId, cascadeDelete: true)
                .Index(t => t.CustomerID)
                .Index(t => t.ProductId);
            
            CreateTable(
                "dbo.EnterpriseInformations",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Address = c.String(),
                        City = c.String(),
                        PostalCode = c.String(),
                        Telephone = c.String(),
                        Fax = c.String(),
                        Email = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Sales",
                c => new
                    {
                        SalesId = c.Int(nullable: false, identity: true),
                        OrderNo = c.String(),
                        CustomerName = c.String(),
                        CustomerPhone = c.String(),
                        CustomerAddress = c.String(),
                        OrderDate = c.DateTime(nullable: false),
                        PaymentMethod = c.String(),
                        TotalAmout = c.Double(nullable: false),
                        CreatedBy = c.String(),
                        CreatedOn = c.DateTime(nullable: false),
                        Status = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SalesId);
            
            CreateTable(
                "dbo.SalesDetails",
                c => new
                    {
                        SalesDetailId = c.Int(nullable: false, identity: true),
                        SalesId = c.Int(nullable: false),
                        ProductId = c.Int(nullable: false),
                        UnitPrice = c.Double(nullable: false),
                        Quantity = c.Int(nullable: false),
                        LineTotal = c.Double(nullable: false),
                        CreatedBy = c.String(),
                        CreatedOn = c.DateTime(nullable: false),
                        Status = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SalesDetailId)
                .ForeignKey("dbo.Sales", t => t.SalesId, cascadeDelete: true)
                .Index(t => t.SalesId);
            
            CreateTable(
                "dbo.Stocks",
                c => new
                    {
                        StockId = c.Int(nullable: false, identity: true),
                        ProductId = c.Int(nullable: false),
                        StockDate = c.String(),
                        Quantity = c.Int(nullable: false),
                        PurchasePrice = c.Double(nullable: false),
                        SellingPrice = c.Double(nullable: false),
                        TotalAmount = c.Double(nullable: false),
                        UpdatedBy = c.String(),
                        UpdatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.StockId)
                .ForeignKey("dbo.Products", t => t.ProductId, cascadeDelete: true)
                .Index(t => t.ProductId);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        Sequence = c.Int(nullable: false, identity: true),
                        Userid = c.String(nullable: false),
                        Firstname = c.String(nullable: false),
                        Lastname = c.String(nullable: false),
                        Usertype = c.String(nullable: false),
                        Password = c.String(),
                        Status = c.String(),
                        EmailAddress = c.String(),
                        Createdby = c.String(),
                        Createdon = c.DateTime(),
                        LastModifiedBy = c.String(),
                        Lastmodifiedon = c.DateTime(),
                    })
                .PrimaryKey(t => t.Sequence);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Stocks", "ProductId", "dbo.Products");
            DropForeignKey("dbo.SalesDetails", "SalesId", "dbo.Sales");
            DropForeignKey("dbo.Credits", "ProductId", "dbo.Products");
            DropForeignKey("dbo.Credits", "CustomerID", "dbo.Customers");
            DropForeignKey("dbo.Bills", "OrderId", "dbo.Orders");
            DropForeignKey("dbo.Orders", "ProductId", "dbo.Products");
            DropForeignKey("dbo.Products", "SupplierID", "dbo.Suppliers");
            DropForeignKey("dbo.Products", "CategoryId", "dbo.Categories");
            DropForeignKey("dbo.Orders", "CustomerId", "dbo.Customers");
            DropIndex("dbo.Stocks", new[] { "ProductId" });
            DropIndex("dbo.SalesDetails", new[] { "SalesId" });
            DropIndex("dbo.Credits", new[] { "ProductId" });
            DropIndex("dbo.Credits", new[] { "CustomerID" });
            DropIndex("dbo.Products", new[] { "SupplierID" });
            DropIndex("dbo.Products", new[] { "CategoryId" });
            DropIndex("dbo.Orders", new[] { "ProductId" });
            DropIndex("dbo.Orders", new[] { "CustomerId" });
            DropIndex("dbo.Bills", new[] { "OrderId" });
            DropTable("dbo.Users");
            DropTable("dbo.Stocks");
            DropTable("dbo.SalesDetails");
            DropTable("dbo.Sales");
            DropTable("dbo.EnterpriseInformations");
            DropTable("dbo.Credits");
            DropTable("dbo.Suppliers");
            DropTable("dbo.Categories");
            DropTable("dbo.Products");
            DropTable("dbo.Customers");
            DropTable("dbo.Orders");
            DropTable("dbo.Bills");
        }
    }
}
