﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class change105 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Products", "CategoryId", "dbo.Categories");
            DropIndex("dbo.Products", new[] { "CategoryId" });
            AddColumn("dbo.Products", "ProductId", c => c.Int(nullable: false));
            AddColumn("dbo.Products", "ProductList_Id", c => c.Int());
            CreateIndex("dbo.Products", "ProductList_Id");
            AddForeignKey("dbo.Products", "ProductList_Id", "dbo.ProductLists", "Id");
            DropColumn("dbo.Products", "CategoryId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Products", "CategoryId", c => c.Int(nullable: false));
            DropForeignKey("dbo.Products", "ProductList_Id", "dbo.ProductLists");
            DropIndex("dbo.Products", new[] { "ProductList_Id" });
            DropColumn("dbo.Products", "ProductList_Id");
            DropColumn("dbo.Products", "ProductId");
            CreateIndex("dbo.Products", "CategoryId");
            AddForeignKey("dbo.Products", "CategoryId", "dbo.Categories", "CategoryId", cascadeDelete: true);
        }
    }
}
