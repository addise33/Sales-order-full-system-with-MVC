﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Credit1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Credits", "CustomerID", "dbo.Customers");
            DropIndex("dbo.Credits", new[] { "CustomerID" });
            AddColumn("dbo.Credits", "CustomerName", c => c.String());
            AddColumn("dbo.Credits", "CustomerAddress", c => c.String());
            AddColumn("dbo.Credits", "CustomerTIN", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Credits", "CustomerTIN");
            DropColumn("dbo.Credits", "CustomerAddress");
            DropColumn("dbo.Credits", "CustomerName");
            CreateIndex("dbo.Credits", "CustomerID");
            AddForeignKey("dbo.Credits", "CustomerID", "dbo.Customers", "Id", cascadeDelete: true);
        }
    }
}
