﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _107 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Products", "PurchasePrice", c => c.Double(nullable: false));
            AddColumn("dbo.Products", "SellingPrice", c => c.Double(nullable: false));
            DropColumn("dbo.Products", "UnitPrice");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Products", "UnitPrice", c => c.Double(nullable: false));
            DropColumn("dbo.Products", "SellingPrice");
            DropColumn("dbo.Products", "PurchasePrice");
        }
    }
}
