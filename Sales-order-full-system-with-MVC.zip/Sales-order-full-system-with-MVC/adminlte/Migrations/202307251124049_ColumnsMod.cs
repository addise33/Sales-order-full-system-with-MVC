﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ColumnsMod : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Sales", "OrderDate", c => c.DateTime());
            AlterColumn("dbo.Sales", "CreatedOn", c => c.DateTime());
            AlterColumn("dbo.SalesDetails", "CreatedOn", c => c.DateTime());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.SalesDetails", "CreatedOn", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Sales", "CreatedOn", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Sales", "OrderDate", c => c.DateTime(nullable: false));
        }
    }
}
