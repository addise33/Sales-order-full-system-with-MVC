﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ColumnsMod5 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Orders", "Remainpayment", c => c.Double(nullable: false));
            DropColumn("dbo.Orders", "GrandTotal");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Orders", "GrandTotal", c => c.Double(nullable: false));
            DropColumn("dbo.Orders", "Remainpayment");
        }
    }
}
