﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _111 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Batches",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        BatchName = c.String(),
                        CreatedBy = c.String(),
                        CreatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.Products", "BatchId", c => c.Int());
            CreateIndex("dbo.Products", "BatchId");
            AddForeignKey("dbo.Products", "BatchId", "dbo.Batches", "Id");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.ProductBatches",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        BatchName = c.String(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            DropForeignKey("dbo.Products", "BatchId", "dbo.Batches");
            DropIndex("dbo.Products", new[] { "BatchId" });
            DropColumn("dbo.Products", "BatchId");
            DropTable("dbo.Batches");
        }
    }
}
