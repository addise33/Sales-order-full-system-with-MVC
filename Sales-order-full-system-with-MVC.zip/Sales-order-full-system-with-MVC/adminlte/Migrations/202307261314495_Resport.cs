﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Resport : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Sales", "CreatedOn", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Sales", "CreatedOn", c => c.DateTime());
        }
    }
}
