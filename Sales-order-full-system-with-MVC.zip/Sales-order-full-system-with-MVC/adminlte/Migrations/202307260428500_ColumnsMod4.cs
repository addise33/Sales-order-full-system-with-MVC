﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ColumnsMod4 : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.SalesDetails", "ProductId");
            AddForeignKey("dbo.SalesDetails", "ProductId", "dbo.Products", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.SalesDetails", "ProductId", "dbo.Products");
            DropIndex("dbo.SalesDetails", new[] { "ProductId" });
        }
    }
}
