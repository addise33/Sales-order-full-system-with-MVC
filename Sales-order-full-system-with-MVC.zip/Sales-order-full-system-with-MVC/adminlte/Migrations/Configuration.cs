﻿namespace adminlte.Migrations
{
    using adminlte.Helpers;
    using adminlte.Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using System.Net.Mail;

    internal sealed class Configuration : DbMigrationsConfiguration<adminlte.Data.AppDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(adminlte.Data.AppDbContext context)
        {
        //    context.users.AddOrUpdate(x => x.Userid,
        //        new users() 
        //        {
        //         Userid="Admin",
        //        Firstname="Admin",
        //        Lastname="Admin",
        //        Usertype = "Admin",
        //        Password= Processor.MD5("Admin"),
        //        Status = "Active",
        //        EmailAddress = "",
        //        Createdby = "Auto Created",
        //        Createdon=DateTime.Now,
        //        LastModifiedBy = "",
        //        Lastmodifiedon = DateTime.Now,
        //        UserPhoto=null,
        //        });  
        }
    }
}
