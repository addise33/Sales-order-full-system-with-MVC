﻿namespace adminlte.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class change107 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.ProductLists", "CreatedOn", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.ProductLists", "CreatedOn", c => c.String());
        }
    }
}
