﻿using adminlte.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace adminlte.Controllers.API
{
    public class CommonAPI : Controller
    {
        private AppDbContext db = new AppDbContext();
        [HttpGet]
        public JsonResult GetAllCustomers()
        {

            var dataList = db.Customers.ToList();
            return Json(dataList, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetAllProduct()
        {

            var dataList = (from prd in db.Products.Include("Category").ToList()
                            join stk in db.Stocks on prd.Id equals stk.ProductId
                            where stk.Quantity > 0
                            select new
                            {
                                ProductId = prd.Id,
                                //CategoryId = prd.CategoryId,
                                Name = prd.ProductName,
                                //CategoryName = prd.Category.CategoryName,
                                PurchasePrice = stk.PurchasePrice,
                                SellingPrice = stk.SellingPrice,
                            }).ToList();


            return Json(dataList, JsonRequestBehavior.AllowGet);
        }

        // GET: CommonAPI
        public ActionResult Index()
        {
            return View();
        }
    }
}