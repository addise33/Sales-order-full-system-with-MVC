﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using adminlte.Models;
using System.Web.UI.WebControls;
using adminlte.Helpers;
using System.Data;
using System.Web.UI;
using adminlte.Data;
using System.Data.Entity;
using static System.Data.Entity.Infrastructure.Design.Executor;

namespace adminlte.Controllers
{
    [RolesAuthorize]
    public class ReportsController : Controller
    {
        private AppDbContext db = new AppDbContext();
        //public async Task<ActionResult> SaleReport(string FltNo, string Departure, string date, string Empno)
        //{
        //    Thread.Sleep(3000);
        //    List<string> searchCriteria = new List<string>();
        //    //if (string.IsNullOrEmpty(FltNo) && string.IsNullOrEmpty(Departure) && string.IsNullOrEmpty(date) && string.IsNullOrEmpty(Empno))
        //    //{
        //    //    TempData["Message"] = "please select at least one option!";
        //    //    return View();
        //    //}
        //    //else
        //    //{

        //        if (FltNo != null && FltNo != "")
        //            searchCriteria.Add("FltNo = '" + FltNo + "'");
        //        if (Departure != null && Departure != "")
        //            searchCriteria.Add("DEP = '" + Departure + "'");
        //        if (date != null && date != "")
        //        {
        //            DateTime date1 = Convert.ToDateTime(date);
        //            string strDate = date1.ToString("dd-MMM-yyyy");
        //            searchCriteria.Add("FltDate = '" + strDate + "'");
        //        }
        //        if (Empno != null && Empno != "")
        //            searchCriteria.Add("EMPNO = '" + Empno + "'");
        //        Sale[] hs = (Sale[])null;
        //        SqlDataSource dataSource = DbReporting.GetDataSource();
        //        string query = "SELECT * FROM dbo.Sales ";
        //        if (searchCriteria != null && searchCriteria.Count > 0)
        //        {
        //            query = query + " WHERE " + searchCriteria[0];
        //            for (int index = 1; index < searchCriteria.Count; ++index)
        //                query = query + " AND " + searchCriteria[index];
        //        }
        //        dataSource.SelectCommand = query;
        //        DataView dataView = (DataView)dataSource.Select(DataSourceSelectArguments.Empty);
        //        if (dataView != null && dataView.Count > 0)
        //        {
        //            hs = new Sale[dataView.Count];
        //            for (int recordIndex = 0; recordIndex < dataView.Count; ++recordIndex)
        //            {
        //                hs[recordIndex] = new Sale();
        //                hs[recordIndex].OrderNo = dataView[recordIndex]["OrderNo"].ToString();
        //                hs[recordIndex].CustomerName = dataView[recordIndex]["CustomerName"].ToString();
        //                hs[recordIndex].CustomerAddress = dataView[recordIndex]["CustomerAddress"].ToString();
        //                hs[recordIndex].CustomerTin = dataView[recordIndex]["CustomerTin"].ToString();
        //                hs[recordIndex].OrderDate = DateTime.Parse(dataView[recordIndex]["OrderDate"].ToString());
        //                hs[recordIndex].PaymentMethod = dataView[recordIndex]["PaymentMethod"].ToString();
        //                hs[recordIndex].TotalAmout = double.Parse(dataView[recordIndex]["TotalAmout"].ToString());
        //            }
        //        }
        //        return View(hs);
        //    //}

        //}

        public ActionResult SalesReport()
        {
            return View();
        }
        public ActionResult SaleReport(string CustomerName,string TIN,string fromdate,string todate)
        {

            var sales = db.Sales.Where(x=>x.CustomerName.Contains(CustomerName) && x.CustomerTin.Contains(TIN)).ToList();
            if (fromdate != "" && todate != "" && fromdate!=null && todate != null)
            {
                DateTime d1 = DateTime.Parse(fromdate);
                DateTime d2 = DateTime.Parse(todate);
                sales = sales.Where(d => d.OrderDate >= d1 && d.OrderDate <= d2).ToList();
            }
         
            return View(sales);
        }
        public ActionResult PurchaseReport(string ProductName, string SerialNo, string fromdate, string todate)
        {

            var purchase = db.Products.Where(x => x.ProductName.Contains(ProductName) && x.SerialNo.Contains(SerialNo)).Include(p => p.Supplier).ToList();
            if (fromdate != "" && todate != "")
                purchase = purchase.Where(d => d.UpdateOn > DateTime.Parse(fromdate) && d.UpdateOn < DateTime.Parse(todate)).ToList();
            return View(purchase);
        }
        public ActionResult OrderReport(string CustomerName, string TIN, string fromdate, string todate,string Status)
        {
            var order = db.OrderMasters.Where(x=>x.CustomerName.Contains(CustomerName) && x.CustomerTIN.Contains(TIN) && x.OrderStatus.Contains(Status)).ToList();
            if (fromdate != "" && todate != "")
                order = order.Where(d => d.OrderDate > DateTime.Parse(fromdate) && d.OrderDate < DateTime.Parse(todate)).ToList();
            return View(order);
        }
        public ActionResult MXInServiceReport(string DeviceName, string SerialNumber, string fromdate, string todate)
        {
            var order = db.maintenancendServices.Where(x => x.DeviceName.Contains(DeviceName) && x.SerialNumber.Contains(SerialNumber) ).Include(m => m.Customer).ToList();
            if (fromdate != "" && todate != "")
                order = order.Where(d => d.UpdatedOn > DateTime.Parse(fromdate) && d.UpdatedOn < DateTime.Parse(todate)).ToList();
            return View(order);
        }
    }
}