﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;
using adminlte.Models.Orders;

namespace adminlte.Controllers
{
    public class CreditsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Credits
        public async Task<ActionResult> Index()
        {
            var credits = db.Credits;
            return View(await credits.ToListAsync());
        }

        // GET: Credits/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Credit credit = await db.Credits.FindAsync(id);
            if (credit == null)
            {
                return HttpNotFound();
            }
            return View(credit);
        }
        [HttpPost]
        public JsonResult SaveInvoiceCredit(Credit credit, List<CreditDetails> creditDetails, Customer customer)
        {
            AppHelper.ReturnMessage retMessage = new AppHelper.ReturnMessage();
            retMessage.IsSuccess = true;

            foreach (var item in creditDetails)
            {
                credit.CreditDetails.Add(new CreditDetails { ProductId = item.ProductId, UnitPrice = item.UnitPrice, Quantity = item.Quantity, LineTotal = item.LineTotal });
                credit.CreditDate = credit.CreditDate;
                credit.PaymentDue = credit.PaymentDue;
                credit.UpdatedOn = DateTime.Now;
                credit.UpdatedBy = User.Identity.Name;
                credit.TotalAmount = credit.TotalAmount + item.LineTotal;
                credit.CustomerAddress = customer.Address;
                credit.CustomerName = customer.FirstName + " " + customer.LastName;
                credit.CustomerTIN = customer.TIN;
                credit.RemainingPayment = credit.TotalAmount - credit.AdvancedPayment;
                credit.Status = adminlte.Helpers.CreditStatus.Open.ToString();
                //sale.PaymentMethod = sale.PaymentMethod;
                var prd = db.Products.Where(x => x.Id == item.ProductId && x.QuantityInStore > 0).FirstOrDefault();
                prd.QuantityInStore = prd.QuantityInStore - item.Quantity;
                db.Entry(prd).State = EntityState.Modified;
            }
            db.Credits.Add(credit);
            retMessage.Messagae = "Save Success!";
            try
            {
                db.SaveChanges();
            }
            catch (Exception)
            {
                retMessage.IsSuccess = false;
            }

            return Json(retMessage, JsonRequestBehavior.AllowGet);
        }
       
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteCredit(int id)
        {
            if (ModelState.IsValid)
            {
                var credit = await db.Credits.FindAsync(id);
                db.Credits.Remove(credit);
                //var orderdetail = await db.OrderDetails.FindAsync(id);
                //db.OrderDetails.Remove(orderdetail);
                await db.SaveChangesAsync();
                TempData["Message"] = "credit has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete credit, please try again!";
            }
            return RedirectToAction("Index");
        }
        // GET: Credits/Create
        public ActionResult Create()
        {
            var lastseq = db.Credits.OrderByDescending(x => x.Id).Select(s => s.Id).FirstOrDefault();
            if (lastseq == 0) lastseq = 1;
            else lastseq = lastseq + 1;
            ViewBag.InvoiceNum = "CR-" + DateTime.Now.ToString("yyyy") + lastseq;
            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName");
            return View();
        }

        // POST: Credits/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,CreditNo,CreditDescription,CreditDate,CustomerID,CreditCategory,PaymentMethod,TotalAmount,AdvancedPayment,RemainingPayment,PaymentDue,UpdatedBy,UpdatedOn")] Credit credit)
        {
            if (ModelState.IsValid)
            {
                db.Credits.Add(credit);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName", credit.CustomerID);
            return View(credit);
        }

        // GET: Credits/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Credit credit = await db.Credits.FindAsync(id);
            if (credit == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName", credit.CustomerID);
            return View(credit);
        }

        // POST: Credits/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,CreditNo,CreditDescription,CreditDate,CustomerID,CreditCategory,PaymentMethod,TotalAmount,AdvancedPayment,RemainingPayment,PaymentDue,UpdatedBy,UpdatedOn,Status")] Credit credit)
        {
            if (ModelState.IsValid)
            {

                var _credit = db.Credits.Find(credit.Id);
                _credit.PaymentDue = credit.PaymentDue;
                _credit.RemainingPayment = _credit.TotalAmount - credit.AdvancedPayment;
                _credit.Status = credit.Status;
                _credit.UpdatedBy = User.Identity.Name;
                _credit.UpdatedOn = DateTime.Now;
                _credit.AdvancedPayment = credit.AdvancedPayment;
                db.Entry(_credit).State = EntityState.Modified;
                await db.SaveChangesAsync();
                if (_credit.Status == "Completed")
                {
                    Sale sale = new Sale();
                    sale.OrderDate = _credit.CreditDate;
                    sale.CreatedOn = DateTime.Now;
                    sale.TotalAmout = _credit.TotalAmount;
                    sale.CustomerAddress = _credit.CustomerAddress;
                    sale.CustomerName = _credit.CustomerName;
                    sale.CustomerTin = _credit.CustomerTIN;
                    sale.SaleType = "Credit Sales";
                    sale.OrderNo = _credit.CreditNo;
                    sale.PaymentMethod = _credit.PaymentMethod;
                    sale.TotalAmout = _credit.TotalAmount;
                    sale.CreatedBy = User.Identity.Name;
                    db.Sales.Add(sale);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index");
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName", credit.CustomerID);
            return View(credit);
        }
        [HttpGet]
        public JsonResult GetAllCustomers()
        {

            var dataList = db.Customers.ToList();
            return Json(dataList, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetAllProduct()
        {

            var dataList = (from prd in db.Products.Include("ProductList").ToList()
                            where prd.QuantityInStore > 0
                            select new
                            {
                                ProductId = prd.Id,
                                //CategoryId = prd.CategoryId,
                                Name = prd.ProductList.ProductName,
                                CategoryName = prd.ProductName,
                                PurchasePrice = prd.PurchasePrice,
                                SellingPrice = prd.SellingPrice,
                                QuantityInStore=prd.QuantityInStore
                            }).ToList();


            return Json(dataList, JsonRequestBehavior.AllowGet);
        }
        // GET: Credits/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Credit credit = await db.Credits.FindAsync(id);
            if (credit == null)
            {
                return HttpNotFound();
            }
            return View(credit);
        }

        // POST: Credits/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Credit credit = await db.Credits.FindAsync(id);
            db.Credits.Remove(credit);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
