﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;

namespace adminlte.Controllers
{
    [RolesAuthorize(Roles = "Admin")]
    public class EnterpriseInformationsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: EnterpriseInformations
        public async Task<ActionResult> Index()
        {
            return View(await db.EnterpriseInformations.ToListAsync());
        }

        // GET: EnterpriseInformations/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EnterpriseInformation enterpriseInformation = await db.EnterpriseInformations.FindAsync(id);
            if (enterpriseInformation == null)
            {
                return HttpNotFound();
            }
            return View(enterpriseInformation);
        }

        // GET: EnterpriseInformations/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EnterpriseInformations/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,Name,Address,City,PostalCode,Telephone,Fax,Email")] EnterpriseInformation enterpriseInformation)
        {
            if (ModelState.IsValid)
            {
                db.EnterpriseInformations.Add(enterpriseInformation);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(enterpriseInformation);
        }

        // GET: EnterpriseInformations/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EnterpriseInformation enterpriseInformation = await db.EnterpriseInformations.FindAsync(id);
            if (enterpriseInformation == null)
            {
                return HttpNotFound();
            }
            return View(enterpriseInformation);
        }

        // POST: EnterpriseInformations/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,Name,Address,City,PostalCode,Telephone,Fax,Email")] EnterpriseInformation enterpriseInformation)
        {
            if (ModelState.IsValid)
            {
                db.Entry(enterpriseInformation).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(enterpriseInformation);
        }

        // GET: EnterpriseInformations/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EnterpriseInformation enterpriseInformation = await db.EnterpriseInformations.FindAsync(id);
            if (enterpriseInformation == null)
            {
                return HttpNotFound();
            }
            return View(enterpriseInformation);
        }

        // POST: EnterpriseInformations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            EnterpriseInformation enterpriseInformation = await db.EnterpriseInformations.FindAsync(id);
            db.EnterpriseInformations.Remove(enterpriseInformation);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
