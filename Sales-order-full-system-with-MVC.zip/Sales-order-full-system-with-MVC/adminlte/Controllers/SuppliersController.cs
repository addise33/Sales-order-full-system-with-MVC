﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;

namespace adminlte.Controllers
{
    [RolesAuthorize]
    public class SuppliersController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Suppliers
        public async Task<ActionResult> Index()
        {
            return View(await db.Suppliers.ToListAsync());
        }

        // GET: Suppliers/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Supplier supplier = await db.Suppliers.FindAsync(id);
            if (supplier == null)
            {
                return HttpNotFound();
            }
            return View(supplier);
        }

        // GET: Suppliers/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Suppliers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "SupplierId,CategoryName,SupplierName,Adress,PhoneNo,Email")] Supplier supplier)
        {
            if (ModelState.IsValid)
            {
                supplier.Updated_by = "Amind";
                supplier.Updated_on = DateTime.Now;
                db.Suppliers.Add(supplier);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(supplier);
        }

        // GET: Suppliers/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Supplier supplier = await db.Suppliers.FindAsync(id);
            if (supplier == null)
            {
                return HttpNotFound();
            }
            return View(supplier);
        }

        // POST: Suppliers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "SupplierId,CategoryName,SupplierName,Adress,PhoneNo,Email,Updated_by,Updated_on")] Supplier supplier)
        {
            if (ModelState.IsValid)
            {
                var _supplier = db.Suppliers.Find(supplier.SupplierId);
                _supplier.SupplierName = supplier.SupplierName;
                _supplier.Updated_by = supplier.Updated_by;
                _supplier.Updated_on = DateTime.Now;
                _supplier.CategoryName = supplier.CategoryName;
                _supplier.Adress= supplier.Adress;
                _supplier.PhoneNo= supplier.PhoneNo;
                _supplier.Email = supplier.Email;
                db.Entry(_supplier).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(supplier);
        }

        // GET: Suppliers/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Supplier supplier = await db.Suppliers.FindAsync(id);
            if (supplier == null)
            {
                return HttpNotFound();
            }
            return View(supplier);
        }

        // POST: Suppliers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Supplier supplier = await db.Suppliers.FindAsync(id);
            db.Suppliers.Remove(supplier);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteSupplier(int id)
        {
            if (ModelState.IsValid)
            {
                var supplier = await db.Suppliers.FindAsync(id);
                db.Suppliers.Remove(supplier);
                await db.SaveChangesAsync();
                TempData["Message"] = "supplier has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete supplier, please try again!";
            }
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
