﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;

namespace adminlte.Controllers
{
    public class MaintenancendServicesController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: MaintenancendServices
        public async Task<ActionResult> Index()
        {
            var maintenancendServices = db.maintenancendServices.Include(m => m.Customer);
            return View(await maintenancendServices.ToListAsync());
        }

        // GET: MaintenancendServices/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MaintenancendService maintenancendService = await db.maintenancendServices.FindAsync(id);
            if (maintenancendService == null)
            {
                return HttpNotFound();
            }
            return View(maintenancendService);
        }

        // GET: MaintenancendServices/Create
        public ActionResult Create()
        {
            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName");
            return View();
        }

        // POST: MaintenancendServices/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,DeviceName,SerialNumber,DeviceDetail,MaitenanceDescription,CustomerID,payment,Advancedpayment,Remainingpayment,ReturnDate,Remarks,UpdatedBy,UpdatedOn")] MaintenancendService maintenancendService)
        {
            if (ModelState.IsValid)
            {
                maintenancendService.Remainingpayment = maintenancendService.payment - maintenancendService.Advancedpayment;
                maintenancendService.UpdatedBy=User.Identity.Name;
                maintenancendService.UpdatedOn=DateTime.Now;
                db.maintenancendServices.Add(maintenancendService);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName", maintenancendService.CustomerID);
            return View(maintenancendService);
        }

        // GET: MaintenancendServices/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MaintenancendService maintenancendService = await db.maintenancendServices.FindAsync(id);
            if (maintenancendService == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName", maintenancendService.CustomerID);
            return View(maintenancendService);
        }

        // POST: MaintenancendServices/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,DeviceName,SerialNumber,DeviceDetail,MaitenanceDescription,CustomerID,payment,Advancedpayment,Remainingpayment,ReturnDate,Remarks,UpdatedBy,UpdatedOn")] MaintenancendService maintenancendService)
        {
            if (ModelState.IsValid)
            {
                var maintenancend = await db.maintenancendServices.FindAsync(maintenancendService.Id);
                maintenancend.Remainingpayment = maintenancendService.payment - maintenancendService.Advancedpayment;
                maintenancend.UpdatedBy = User.Identity.Name;
                maintenancend.ReturnDate=maintenancendService.ReturnDate;
                maintenancend.UpdatedOn = DateTime.Now;
                maintenancend.Advancedpayment = maintenancendService.Advancedpayment;
                db.Entry(maintenancend).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "Id", "FirstName", maintenancendService.CustomerID);
            return View(maintenancendService);
        }

        // GET: MaintenancendServices/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MaintenancendService maintenancendService = await db.maintenancendServices.FindAsync(id);
            if (maintenancendService == null)
            {
                return HttpNotFound();
            }
            return View(maintenancendService);
        }

        // POST: MaintenancendServices/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            MaintenancendService maintenancendService = await db.maintenancendServices.FindAsync(id);
            db.maintenancendServices.Remove(maintenancendService);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> Deleteservice(int id)
        {
            if (ModelState.IsValid)
            {
                var order = await db.maintenancendServices.FindAsync(id);
                db.maintenancendServices.Remove(order);
                //var orderdetail = await db.OrderDetails.FindAsync(id);
                //db.OrderDetails.Remove(orderdetail);
                await db.SaveChangesAsync();
                TempData["Message"] = "service has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete service, please try again!";
            }
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
