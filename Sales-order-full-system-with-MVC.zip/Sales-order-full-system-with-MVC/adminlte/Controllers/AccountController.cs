﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using adminlte.Models;
using adminlte.Data;
using System.Web.Security;
using System.Data.Entity;
using System.Net;
using System.Data.Entity.Validation;
using System.Security.Cryptography;
using System.Text;
using adminlte.Helpers;
using System.Collections.Generic;
using System.IO;

namespace adminlte.Controllers
{
    [RolesAuthorize]
    public class AccountController : Controller
    {
        private ApplicationSignInManager _signInManager;
        private ApplicationUserManager _userManager;
        private AppDbContext db = new AppDbContext();
        public AccountController()
        {
        }

        public AccountController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set
            {
                _signInManager = value;
            }
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }
        public ActionResult Test()
        {
            return View();
        }
        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            users result = db.users.Where(x => x.Userid == model.UserId).FirstOrDefault();
            if (result == null)
            {
                return RedirectToAction("Login", "Account", new { ac = "notfound" });
            }
            else if (result.Status != "Active")
            {
                return RedirectToAction("Login", "Account", new { ac = "locked" });
            }
            else
            {
                if (result.Password == Processor.MD5(model.Password))
                {

                    FormsAuthentication.SetAuthCookie(model.UserId, model.RememberMe);
                    FormsAuthentication.SetAuthCookie(Convert.ToString(model.UserId), model.RememberMe);
                    var authTicket = new FormsAuthenticationTicket(1, model.UserId, DateTime.Now, DateTime.Now.AddMinutes(30), false, result.Usertype);
                    string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                    var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                    HttpContext.Response.Cookies.Add(authCookie);
                    //Based on the Role we can transfer the user to different page                   
                    return RedirectToAction("Dashboard", "Dashboard");

                }
                else
                {
                    return RedirectToAction("Login", "Account", new { ac = "incorrect" });
                }
            }
        }
        [AllowAnonymous]
        public ActionResult AccessDenied()
        {
            return View();
        }
        //
        // GET: /Account/VerifyCode
        [AllowAnonymous]
        public async Task<ActionResult> VerifyCode(string provider, string returnUrl, bool rememberMe)
        {
            // Require that the user has already logged in via username/password or external login
            if (!await SignInManager.HasBeenVerifiedAsync())
            {
                return View("Error");
            }
            return View(new VerifyCodeViewModel { Provider = provider, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        //
        // POST: /Account/VerifyCode
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
 [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // The following code protects for brute force attacks against the two factor codes. 
            // If a user enters incorrect codes for a specified amount of time then the user account 
            // will be locked out for a specified amount of time. 
            // You can configure the account lockout settings in IdentityConfig
            var result = await SignInManager.TwoFactorSignInAsync(model.Provider, model.Code, isPersistent: model.RememberMe, rememberBrowser: model.RememberBrowser);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(model.ReturnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.Failure:
                default:
                    ModelState.AddModelError("", "Invalid code.");
                    return View(model);
            }
        }

        //
        // GET: /Account/Register
        [AllowAnonymous]
 [RolesAuthorize(Roles = "Admin")]
        public ActionResult Register()
        {
            return View();
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
 [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser { UserName = model.Email, Email = model.Email };
                var result = await UserManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);

                    // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=320771
                    // Send an email with this link
                    // string code = await UserManager.GenerateEmailConfirmationTokenAsync(user.Id);
                    // var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);
                    // await UserManager.SendEmailAsync(user.Id, "Confirm your account", "Please confirm your account by clicking <a href=\"" + callbackUrl + "\">here</a>");

                    return RedirectToAction("Index", "Home");
                }
                AddErrors(result);
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }
        public ActionResult ChangePassword()
        {
            string userName = User.Identity.Name;
            var user = db.users.Where(x => x.Userid == userName).FirstOrDefault();
            if (user != null)
            {
                ChangeNewPassword model = new ChangeNewPassword()
                {
                    Sequence = user.Sequence,
                };
                return View(model);
            }
            else
            {
                return View();
            }
        }
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(ChangeNewPassword changePassword)
        {
            if (ModelState.IsValid)
            {
                string userName = User.Identity.Name;
                var user = db.users.Where(x => x.Userid == userName).FirstOrDefault();
                if (Processor.MD5(changePassword.CurrentPassword) != user.Password)
                {
                    TempData["Message"] = "Current password is not correct!";
                    return RedirectToAction("ChangePassword", "Account");
                }
                else
                {
                    try
                    {
                        user.Password = Processor.MD5(changePassword.Password);
                        user.LastModifiedBy = userName;
                        user.Lastmodifiedon = DateTime.Now;
                        db.Entry(user).State = EntityState.Modified;
                        db.SaveChanges();
                        TempData["Message"] = "Password has been changed successfuly!";
                        return RedirectToAction("ChangePassword", "Account");
                    }
                    catch (Exception)
                    {
                        TempData["Message"] = "Can not change password, please try again!";
                        return RedirectToAction("ChangePassword", "Account");

                    }
                }
            }
            return View(changePassword);
        }
        [RolesAuthorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            byte[] imageData = null;
            if (Request.Files.Count > 0)
            {
                HttpPostedFileBase poImgFile = Request.Files["UserPhoto"];

                using (var binary = new BinaryReader(poImgFile.InputStream))
                {
                    imageData = binary.ReadBytes(poImgFile.ContentLength);
                }
            }
            var user = db.users.Find(id);
            var viewModel = new UsersView()
            {
                Sequence = user.Sequence,
                Userid = user.Userid,
                Firstname = user.Firstname,
                Lastname = user.Lastname,
                Usertype = user.Usertype,
                EmailAddress = user.EmailAddress,
                UserPhoto=imageData
            };
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(viewModel);
        }
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        [RolesAuthorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Exclude = "UserPhoto")] UsersView users)
        {
            if (ModelState.IsValid)
            {
                byte[] imageData = null;
                if (Request.Files.Count > 0)
                {
                    HttpPostedFileBase poImgFile = Request.Files["UserPhoto"];

                    using (var binary = new BinaryReader(poImgFile.InputStream))
                    {
                        imageData = binary.ReadBytes(poImgFile.ContentLength);
                    }
                }
                int Id = users.Sequence;
                users ToUpdate = db.users.Find(Id);
                //ToUpdate.Firstname = users.Firstname;
                ToUpdate.Lastname = users.Lastname;
                ToUpdate.EmailAddress = users.EmailAddress;
                ToUpdate.Usertype = users.Usertype;
                ToUpdate.LastModifiedBy = User.Identity.Name;
                ToUpdate.Lastmodifiedon = DateTime.Now;
                ToUpdate.UserPhoto=imageData;
                db.Entry(ToUpdate).State = EntityState.Modified;
                db.SaveChanges();
                TempData["Message"] = "Account has been edited!";
                return RedirectToAction("Users");
            }
            else
                TempData["Message"] = "Couldn't edit account, please try again!";
            return View(users);
        }
        //
        // GET: /Account/ConfirmEmail
        [AllowAnonymous]
        public async Task<ActionResult> ConfirmEmail(string userId, string code)
        {
            if (userId == null || code == null)
            {
                return View("Error");
            }
            var result = await UserManager.ConfirmEmailAsync(userId, code);
            return View(result.Succeeded ? "ConfirmEmail" : "Error");
        }
        [AllowAnonymous]
        public ActionResult NewPassword(int id)
        {
            var user = db.users.Where(x => x.Sequence == id).FirstOrDefault();
            if (user != null)
            {
                ChangeNewPassword model = new ChangeNewPassword()
                {
                    Sequence = user.Sequence,
                };
                return View(model);
            }
            else
            {
                return View();
            }


        }
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult NewPassword(ChangeNewPassword changePassword)
        {
            if (ModelState.IsValid)
            {
                users user = db.users.Where(x => x.Sequence == changePassword.Sequence).FirstOrDefault();
                if (user == null)
                {
                    return RedirectToAction("NewPassword", "Account", new { ac = "notfound" });
                }
                else
                {
                    try
                    {
                        user.Password = Processor.MD5(changePassword.Password);
                        user.LastModifiedBy = "Self Reset";
                        user.Lastmodifiedon = DateTime.Now;
                        db.Entry(user).State = EntityState.Modified;
                        db.SaveChanges();
                        return RedirectToAction("Login", "Account");
                    }
                    catch (Exception)
                    {
                        return RedirectToAction("NewPassword", "Account", new { ac = "error" });

                    }
                }

            }

            // If we got this far, something failed, redisplay form
            return View(changePassword);

        }
        //
        // GET: /Account/ForgotPassword
        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        //
        // POST: /Account/ForgotPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                users user = db.users.Where(x => x.Userid == model.UserId).FirstOrDefault();
                if (user == null)
                {
                    return RedirectToAction("ForgotPassword", "Account", new { ac = "notfound" });
                }
                else
                {
                    try
                    {
                        string NewPassword = Processor.GetRandomPassword(10);
                        user.Password = Processor.MD5(NewPassword);
                      
                        db.Entry(user).State = EntityState.Modified;
                        db.SaveChanges();
                        Processor.Sendpassword(NewPassword, model.UserId);
                        return RedirectToAction("ForgotPassword", "Account", new { ac = "success" });
                    }
                    catch (Exception)
                    {
                        return RedirectToAction("ForgotPassword", "Account", new { ac = "error" });

                    }

                }
                //var user = await UserManager.FindByNameAsync(model.UserId);
                //if (user == null || !(await UserManager.IsEmailConfirmedAsync(user.Id)))
                //{
                //    // Don't reveal that the user does not exist or is not confirmed
                //    return View("ForgotPasswordConfirmation");
                //}

                // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=320771
                // Send an email with this link
                // string code = await UserManager.GeneratePasswordResetTokenAsync(user.Id);
                // var callbackUrl = Url.Action("ResetPassword", "Account", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);		
                // await UserManager.SendEmailAsync(user.Id, "Reset Password", "Please reset your password by clicking <a href=\"" + callbackUrl + "\">here</a>");
                // return RedirectToAction("ForgotPasswordConfirmation", "Account");
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }
        //
        // GET: /Account/ForgotPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {
            return View();
        }
        //
        // GET: /Account/ResetPassword

 [RolesAuthorize(Roles = "Admin")]
        public ActionResult ResetPassword(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = db.users.Find(id);
            var viewModel = new users()
            {
                Sequence = user.Sequence,
                Userid = user.Userid,
                Password = user.Password,
            };
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(viewModel);
        }

        //
        // POST: /Account/ResetPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await UserManager.FindByNameAsync(model.Email);
            if (user == null)
            {
                // Don't reveal that the user does not exist
                return RedirectToAction("ResetPasswordConfirmation", "Account");
            }
            var result = await UserManager.ResetPasswordAsync(user.Id, model.Code, model.Password);
            if (result.Succeeded)
            {
                return RedirectToAction("ResetPasswordConfirmation", "Account");
            }
            AddErrors(result);
            return View();
        }

        //
        // GET: /Account/ResetPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ResetPasswordConfirmation()
        {
            return View();
        }

        //
        // POST: /Account/ExternalLogin
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLogin(string provider, string returnUrl)
        {
            // Request a redirect to the external login provider
            return new ChallengeResult(provider, Url.Action("ExternalLoginCallback", "Account", new { ReturnUrl = returnUrl }));
        }

        //
        // GET: /Account/SendCode
        [AllowAnonymous]
        public async Task<ActionResult> SendCode(string returnUrl, bool rememberMe)
        {
            var userId = await SignInManager.GetVerifiedUserIdAsync();
            if (userId == null)
            {
                return View("Error");
            }
            var userFactors = await UserManager.GetValidTwoFactorProvidersAsync(userId);
            var factorOptions = userFactors.Select(purpose => new SelectListItem { Text = purpose, Value = purpose }).ToList();
            return View(new SendCodeViewModel { Providers = factorOptions, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        //
        // POST: /Account/SendCode
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SendCode(SendCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            // Generate the token and send it
            if (!await SignInManager.SendTwoFactorCodeAsync(model.SelectedProvider))
            {
                return View("Error");
            }
            return RedirectToAction("VerifyCode", new { Provider = model.SelectedProvider, ReturnUrl = model.ReturnUrl, RememberMe = model.RememberMe });
        }

        //
        // GET: /Account/ExternalLoginCallback
        [AllowAnonymous]
        public async Task<ActionResult> ExternalLoginCallback(string returnUrl)
        {
            var loginInfo = await AuthenticationManager.GetExternalLoginInfoAsync();
            if (loginInfo == null)
            {
                return RedirectToAction("Login");
            }

            // Sign in the user with this external login provider if the user already has a login
            var result = await SignInManager.ExternalSignInAsync(loginInfo, isPersistent: false);
            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(returnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = false });
                case SignInStatus.Failure:
                default:
                    // If the user does not have an account, then prompt the user to create an account
                    ViewBag.ReturnUrl = returnUrl;
                    ViewBag.LoginProvider = loginInfo.Login.LoginProvider;
                    return View("ExternalLoginConfirmation", new ExternalLoginConfirmationViewModel { Email = loginInfo.Email });
            }
        }

        //
        // POST: /Account/ExternalLoginConfirmation
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ExternalLoginConfirmation(ExternalLoginConfirmationViewModel model, string returnUrl)
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Manage");
            }

            if (ModelState.IsValid)
            {
                // Get the information about the user from the external login provider
                var info = await AuthenticationManager.GetExternalLoginInfoAsync();
                if (info == null)
                {
                    return View("ExternalLoginFailure");
                }
                var user = new ApplicationUser { UserName = model.Email, Email = model.Email };
                var result = await UserManager.CreateAsync(user);
                if (result.Succeeded)
                {
                    result = await UserManager.AddLoginAsync(user.Id, info.Login);
                    if (result.Succeeded)
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                        return RedirectToLocal(returnUrl);
                    }
                }
                AddErrors(result);
            }

            ViewBag.ReturnUrl = returnUrl;
            return View(model);
        }
        //[HttpGet]
        //public ActionResult LogOff()
        //{
        //    FormsAuthentication.SignOut();
        //    return RedirectToAction("Login", "Account");
        //}
        //
        // POST: /Account/LogOff
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult LogOff()
        //{
        //    AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
        //    return RedirectToAction("Index", "Home");
        //}
 [RolesAuthorize(Roles = "Admin")]
        public ActionResult Users()
        {

            List<UsersView> allSearch = db
          .users
          .Select(s => new UsersView
          {
              Sequence = s.Sequence,
              Userid = s.Userid,
              Firstname = s.Firstname,
              Lastname = s.Lastname,
              Usertype = s.Usertype,
              Status = s.Status,
              EmailAddress = s.EmailAddress,
              UserPhoto=s.UserPhoto
          })
          .ToList();


            return View(allSearch);
        }
       [RolesAuthorize(Roles = "Admin")]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [RolesAuthorize(Roles = "Admin")]
        public ActionResult Create([Bind(Include = "Userid,Firstname,Lastname,Usertype,EmailAddress")] users users)
        {
            if (ModelState.IsValid)
            {
                byte[] imageData = null;
                if (Request.Files.Count > 0)
                {
                    HttpPostedFileBase poImgFile = Request.Files["UserPhoto"];

                    using (var binary = new BinaryReader(poImgFile.InputStream))
                    {
                        imageData = binary.ReadBytes(poImgFile.ContentLength);
                    }
                }
                users.Password = Processor.MD5(users.Userid);
                users.Status = "Active";
                users.Createdby = User.Identity.Name;
                users.LastModifiedBy = "";
                users.Createdon = DateTime.Now;
                users.Lastmodifiedon = null;
                users.UserPhoto = imageData;
                db.users.Add(users);
                db.SaveChanges();
                TempData["Message"] = "Account has been created!";
                return RedirectToAction("Users");
            }
            else
                TempData["Message"] = "Couldn't add account, please try again!";

            return View("Users");
        }
 [RolesAuthorize(Roles = "Admin")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var result = db.users
                 .Where(x => x.Sequence == id)
                 .Select(s => new UserDetailView
                 {
                     Sequence = s.Sequence,
                     Userid = s.Userid,
                     Firstname = s.Firstname,
                     Lastname = s.Lastname,
                     Status = s.Status,
                     Usertype= s.Usertype,
                     EmailAddress = s.EmailAddress,
                     Createdby = s.Createdby,
                     Createdon = s.Createdon,
                     LastModifiedBy = s.LastModifiedBy,
                     Lastmodifiedon = s.Lastmodifiedon,
                 }).SingleOrDefault();

            if (result == null)
            {
                return View("Users");
            }
            return View(result);
        }
        public ActionResult UserProfile(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var result = db.users
                 .Where(x => x.Userid == id)
                 .Select(s => new UserDetailView
                 {
                     Sequence = s.Sequence,
                     Userid = s.Userid,
                     Firstname = s.Firstname,
                     Lastname = s.Lastname,
                     Status = s.Status,
                     EmailAddress = s.EmailAddress,
                     Usertype = s.Usertype, 
                     Createdby = s.Createdby,
                     Createdon = s.Createdon,
                     LastModifiedBy = s.LastModifiedBy,
                     Lastmodifiedon = s.Lastmodifiedon,
                 }).SingleOrDefault();

            if (result == null)
            {
                return View("Users");
            }
            return View(result);
        }
 [RolesAuthorize(Roles = "Admin")]
        public ActionResult Lock(int? id)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    users user = db.users.Where(x => x.Sequence == id).FirstOrDefault();
                    if (user == null)
                    {
                        return HttpNotFound();
                    }
                    user.Status = "Locked";
                    user.LastModifiedBy = User.Identity.Name;
                    user.Lastmodifiedon = DateTime.Now;

                    //user.Status = "Locked";
                    db.Entry(user).State = EntityState.Modified;
                    db.SaveChanges();
                    TempData["Message"] = "Account Has been locked!";
                }
                else
                {
                    TempData["Message"] = "Couldn't lock, please try again!";
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                string c;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string x = "Property: {0} Error: {1}" + validationError.PropertyName + validationError.ErrorMessage;
                    }
                }
            }
            return RedirectToAction("Users", "Account");


        }
 [RolesAuthorize(Roles = "Admin")]
        public ActionResult UnLock(int? id)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    users user = db.users.Where(x => x.Sequence == id).FirstOrDefault();
                    if (user == null)
                    {
                        return HttpNotFound();
                    }
                    user.Status = "Active";
                    user.LastModifiedBy = User.Identity.Name;
                    user.Lastmodifiedon = DateTime.Now;

                    //user.Status = "Locked";
                    db.Entry(user).State = EntityState.Modified;
                    db.SaveChanges();
                    TempData["Message"] = "Account Has been unlocked!";
                }
                else
                {
                    TempData["Message"] = "Couldn't unlock, please try again!";
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                string c;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string x = "Property: {0} Error: {1}" + validationError.PropertyName + validationError.ErrorMessage;
                    }
                }
            }
            return RedirectToAction("Users", "Account");


        }
 [RolesAuthorize(Roles = "Admin")]
        public ActionResult ResetPass(int? id)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    users user = db.users.Where(x => x.Sequence == id).FirstOrDefault();
                    if (user == null)
                    {
                        return HttpNotFound();
                    }
                    user.Password = Processor.MD5(user.Userid);
                    user.LastModifiedBy = User.Identity.Name;
                    user.Lastmodifiedon = DateTime.Now;

                    //user.Status = "Locked";
                    db.Entry(user).State = EntityState.Modified;
                    db.SaveChanges();
                    TempData["Message"] = "Password has been reset to: " + user.Userid;
                }
                else
                {
                    TempData["Message"] = "Couldn't reset password, please try again!";
                }
            }
            catch (DbEntityValidationException)
            {

            }
            return RedirectToAction("Users", "Account");


        }
        public ActionResult LogOff()
        {
            //FormsAuthentication.SignOut();
            FormsAuthentication.SignOut();
            //Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //Response.Cache.SetExpires(DateTime.Now);
            //Response.Cache.SetNoServerCaching();
            //Response.Cache.SetNoStore();
            return RedirectToAction("Login", "Account");
        }
        public ActionResult _popup()
        {
            return View();
        }
        // GET: /Account/ExternalLoginFailure
        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_userManager != null)
                {
                    _userManager.Dispose();
                    _userManager = null;
                }

                if (_signInManager != null)
                {
                    _signInManager.Dispose();
                    _signInManager = null;
                }
            }

            base.Dispose(disposing);
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        public static string GenerateSHA512String(string inputString)
        {
            SHA512 sha512 = SHA512Managed.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(inputString);
            byte[] hash = sha512.ComputeHash(bytes);
            return GetStringFromHash(hash);
        }
        private static string GetStringFromHash(byte[] hash)
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                result.Append(hash[i].ToString("X2"));
            }
            return result.ToString();
        }

        #endregion
    }
}