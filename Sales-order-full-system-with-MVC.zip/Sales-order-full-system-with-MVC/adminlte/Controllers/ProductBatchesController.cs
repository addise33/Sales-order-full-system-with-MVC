﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using System.Text.RegularExpressions;
using adminlte.Helpers;

namespace adminlte.Controllers
{
    public class ProductBatchesController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: ProductBatches
        public async Task<ActionResult> Index()
        {
            return View(await db.Batchs.ToListAsync());
        }

        // GET: ProductBatches/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Batch productBatch = await db.Batchs.FindAsync(id);
            if (productBatch == null)
            {
                return HttpNotFound();
            }
            return View(productBatch);
        }

        // GET: ProductBatches/Create
        public ActionResult Create()
        {
            Batch productBatch=new Batch();
            productBatch.BatchName = "B-"+DateTime.Now.ToString("yyyyMMMdd").ToUpper();
            productBatch.CreatedBy=User.Identity.Name;
            productBatch.CreatedOn= DateTime.Now;
            db.Batchs.Add(productBatch);
             db.SaveChanges();
            return RedirectToAction("Index");
        }

        // POST: ProductBatches/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,BatchName,CreatedBy,UpdatedOn")] Batch productBatch)
        {
            if (ModelState.IsValid)
            {
                db.Batchs.Add(productBatch);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(productBatch);
        }

        // GET: ProductBatches/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Batch productBatch = await db.Batchs.FindAsync(id);
            if (productBatch == null)
            {
                return HttpNotFound();
            }
            return View(productBatch);
        }

        // POST: ProductBatches/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,BatchName,CreatedBy,UpdatedOn")] Batch productBatch)
        {
            if (ModelState.IsValid)
            {
                db.Entry(productBatch).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(productBatch);
        }

        // GET: ProductBatches/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Batch productBatch = await db.Batchs.FindAsync(id);
            if (productBatch == null)
            {
                return HttpNotFound();
            }
            return View(productBatch);
        }

        // POST: ProductBatches/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Batch productBatch = await db.Batchs.FindAsync(id);
            db.Batchs.Remove(productBatch);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteBatch(int id)
        {
            if (ModelState.IsValid)
            {
                var product = await db.Batchs.FindAsync(id);
                db.Batchs.Remove(product);
                await db.SaveChangesAsync();
                TempData["Message"] = "batch has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete batch, please try again!";
            }
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
