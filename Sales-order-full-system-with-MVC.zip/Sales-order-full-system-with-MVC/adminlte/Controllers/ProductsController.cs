﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;

namespace adminlte.Controllers
{
    [RolesAuthorize]
    public class ProductsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Products
        public async Task<ActionResult> Index()
        {
            var products = db.Products.Include(p => p.Supplier).Include(c=>c.ProductList).Include(b=>b.Batch);
            return View(await products.ToListAsync());
        }

        // GET: Products/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = await db.Products.FindAsync(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // GET: Products/Create
        public ActionResult Create()
        {
            ViewBag.BatchId = new SelectList(db.Batchs, "Id", "BatchName");
            ViewBag.ProductListId = new SelectList(db.ProductLists, "Id", "ProductName");
            ViewBag.SupplierID = new SelectList(db.Suppliers, "SupplierId", "SupplierName");
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,ProductName,SerialNo,BatchId,ProductListId,SupplierID,PurchasePrice,SellingPrice,QuantityInStore,QuantityInOrder,TotalPrice")] Product product)
        {
            if (ModelState.IsValid)
            { 
                var isexist=db.Products.Where(x=>x.ProductListId==product.ProductListId && x.BatchId==product.BatchId).FirstOrDefault();
                if (isexist != null)
                {
                    ViewBag.BatchId = new SelectList(db.Batchs, "Id", "BatchName", product.BatchId);

                    ViewBag.ProductListId = new SelectList(db.ProductLists, "Id", "ProductName", product.ProductListId);
                    ViewBag.SupplierID = new SelectList(db.Suppliers, "SupplierId", "SupplierName", product.SupplierID);
                    TempData["Message"] = "Product is already in stock";
                    return View();
                }

                int total = product.QuantityInStore + product.QuantityInOrder;
                product.TotalPrice = product.PurchasePrice * total;
                product.UpdateBy = "Admin";
                product.UpdateOn =DateTime.Now;
                db.Products.Add(product);
                await db.SaveChangesAsync();
                //#region updatestock
                //var stock=new Stock();
                //stock.ProductId = product.Id;
                //stock.StockDate = DateTime.Now.ToString("dd-MMM-yyyy");
                //stock.Quantity = total;
                //stock.PurchasePrice = product.PurchasePrice;
                //stock.TotalAmount = product.PurchasePrice * total;
                //stock.SellingPrice = 0.0;
                //stock.UpdatedBy = User.Identity.Name;
                //stock.UpdatedOn = DateTime.Now;
                //db.Stocks.Add(stock);
                //await db.SaveChangesAsync();
                //#endregion
                return RedirectToAction("Index");
            }
            ViewBag.BatchId = new SelectList(db.Batchs, "Id", "BatchName", product.BatchId);
            ViewBag.ProductListId = new SelectList(db.ProductLists, "Id", "ProductName", product.ProductListId);
            ViewBag.SupplierID = new SelectList(db.Suppliers, "SupplierId", "SupplierName", product.SupplierID);
            return View(product);
        }

        // GET: Products/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = await db.Products.FindAsync(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            ViewBag.BatchId = new SelectList(db.Batchs, "Id", "BatchName", product.BatchId);
            ViewBag.ProductListId = new SelectList(db.ProductLists, "Id", "ProductName", product.ProductListId);
            ViewBag.SupplierID = new SelectList(db.Suppliers, "SupplierId", "SupplierName", product.SupplierID);
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,ProductName,SerialNo,SupplierID,BatchId,PurchasePrice,SellingPrice,QuantityInStore,QuantityInOrder,TotalPrice,UpdateBy,UpdateOn")] Product product)
        {
            if (ModelState.IsValid)
            {

                var _product=db.Products.Find(product.Id);
                _product.SupplierID=product.SupplierID;
                _product.BatchId=product.BatchId;
                _product.ProductName=product.ProductName;
                _product.QuantityInStore = product.QuantityInStore;
                _product.PurchasePrice = product.PurchasePrice;
                _product.SellingPrice = product.SellingPrice;
                int total = product.QuantityInStore + product.QuantityInOrder;
                _product.TotalPrice = product.PurchasePrice * total;
                _product.UpdateBy = User.Identity.Name;
                _product.UpdateOn = DateTime.Now;
                db.Entry(_product).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            ViewBag.BatchId = new SelectList(db.Batchs, "Id", "BatchName", product.BatchId);
            ViewBag.ProductListId = new SelectList(db.ProductLists, "Id", "ProductName", product.ProductListId);
            ViewBag.SupplierID = new SelectList(db.Suppliers, "SupplierId", "SupplierName", product.SupplierID);
            return View(product);
        }

        // GET: Products/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = await db.Products.FindAsync(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Product product = await db.Products.FindAsync(id);
            db.Products.Remove(product);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> Deleteproduct(int id)
        {
            if (ModelState.IsValid)
            {
                var product = await db.Products.FindAsync(id);
                db.Products.Remove(product);
                await db.SaveChangesAsync();
                TempData["Message"] = "product has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete product, please try again!";
            }
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
