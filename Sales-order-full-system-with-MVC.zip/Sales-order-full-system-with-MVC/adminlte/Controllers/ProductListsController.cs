﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;

namespace adminlte.Controllers
{
    public class ProductListsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: ProductLists
        public async Task<ActionResult> Index()
        {
            var productLists = db.ProductLists.Include(p => p.Category);
            return View(await productLists.ToListAsync());
        }

        // GET: ProductLists/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductList productList = await db.ProductLists.FindAsync(id);
            if (productList == null)
            {
                return HttpNotFound();
            }
            return View(productList);
        }

        // GET: ProductLists/Create
        public ActionResult Create()
        {
            ViewBag.CategoryId = new SelectList(db.Categorys, "CategoryId", "CategoryName");
            return View();
        }

        // POST: ProductLists/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,ProductName,CategoryId,CreatedBy,CreatedOn")] ProductList productList)
        {
            if (ModelState.IsValid)
            {
                productList.CreatedBy=User.Identity.Name;
                productList.CreatedOn=DateTime.Now;
                db.ProductLists.Add(productList);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.CategoryId = new SelectList(db.Categorys, "CategoryId", "CategoryName", productList.CategoryId);
            return View(productList);
        }

        // GET: ProductLists/Edit/5
        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductList productList = await db.ProductLists.FindAsync(id);
            if (productList == null)
            {
                return HttpNotFound();
            }
            ViewBag.CategoryId = new SelectList(db.Categorys, "CategoryId", "CategoryName", productList.CategoryId);
            return View(productList);
        }

        // POST: ProductLists/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,ProductName,CategoryId,CreatedBy,CreatedOn")] ProductList productList)
        {
            if (ModelState.IsValid)
            {
                var toupdate=db.ProductLists.Find(productList.Id);
                toupdate.ProductName=productList.ProductName;
                toupdate.Category=productList.Category;
                toupdate.CreatedBy = User.Identity.Name;
                toupdate.CreatedOn = DateTime.Now;
                db.Entry(toupdate).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            ViewBag.CategoryId = new SelectList(db.Categorys, "CategoryId", "CategoryName", productList.CategoryId);
            return View(productList);
        }

        // GET: ProductLists/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductList productList = await db.ProductLists.FindAsync(id);
            if (productList == null)
            {
                return HttpNotFound();
            }
            return View(productList);
        }

        // POST: ProductLists/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            ProductList productList = await db.ProductLists.FindAsync(id);
            db.ProductLists.Remove(productList);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> Deleteproductlist(int id)
        {
            if (ModelState.IsValid)
            {
                var product = await db.ProductLists.FindAsync(id);
                db.ProductLists.Remove(product);
                await db.SaveChangesAsync();
                TempData["Message"] = "product has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete product, please try again!";
            }
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
