﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;
using System.Web.UI.WebControls;
using adminlte.Models.ViewModel;
using System.Threading.Tasks;

namespace adminlte.Controllers
{
    [RolesAuthorize]
    public class SalesController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Sales
        public ActionResult Index()
        {
            var dataList = db.Sales.ToList();
            return View(dataList);
        }

        // GET: Sales/Create
        public ActionResult Create()
        {
            ViewBag.ProductId = new SelectList(db.Products, "Id", "ProductName");
            return View();
        }

        public ActionResult PrintInvoice(int? id)
        {
            var viewModel = new SaleDetailsView
            {
                Sale=db.Sales.Find(id),
                SalesDetail=db.SalesDetails.Where(x=>x.SalesId== id).Include(p=>p.Product).ToList(),
            };
            //var report = new ViewAsPdf("StandardPrescriptionPartial", viewModel);
            //return report;
            return View(viewModel);
        }
        public ActionResult InvoicePrint(int? id)
        {
            
            var viewModel = new SaleDetailsView
            {
                Sale = db.Sales.Find(id),
                SalesDetail = db.SalesDetails.Where(x => x.SalesId == id).Include(p => p.Product).ToList(),
                AmountInWords=AppHelper.ConvertToWords(db.Sales.Where(x => x.SalesId == id).Select(s=>s.TotalAmout).FirstOrDefault().ToString()),
            };
            
            return View(viewModel);
        }


        //// POST: Sales/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> Create([Bind(Include = "SaleId,SaleDate,InvoiceNumber,ProductId,UnitPrice,Quantity,TotalAmount,UpdatedBy,UpdatedOn")] SaleOld sale)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.SaleOlds.Add(sale);
        //        await db.SaveChangesAsync();
        //        return RedirectToAction("Index");
        //    }

        //    ViewBag.ProductId = new SelectList(db.Products, "Id", "ProductName", sale.ProductId);
        //    return View(sale);
        //}

        //// GET: Sales/Edit/5
        //public async Task<ActionResult> Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    SaleOld sale = await db.SaleOlds.FindAsync(id);
        //    if (sale == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    ViewBag.ProductId = new SelectList(db.Products, "Id", "ProductName", sale.ProductId);
        //    return View(sale);
        //}

        //// POST: Sales/Edit/5
        //// To protect from overposting attacks, enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> Edit([Bind(Include = "SaleId,SaleDate,InvoiceNumber,ProductId,UnitPrice,Quantity,TotalAmount,UpdatedBy,UpdatedOn")] SaleOld sale)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(sale).State = EntityState.Modified;
        //        await db.SaveChangesAsync();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.ProductId = new SelectList(db.Products, "Id", "ProductName", sale.ProductId);
        //    return View(sale);
        //}

        //// GET: Sales/Delete/5
        //public async Task<ActionResult> Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    SaleOld sale = await db.SaleOlds.FindAsync(id);
        //    if (sale == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(sale);
        //}

        //// POST: Sales/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> DeleteConfirmed(int id)
        //{
        //    SaleOld sale = await db.SaleOlds.FindAsync(id);
        //    db.SaleOlds.Remove(sale);
        //    await db.SaveChangesAsync();
        //    return RedirectToAction("Index");
        //}
        //}
        [HttpGet]
        public JsonResult GetAllCustomers()
        {
         
            var dataList = db.Customers.ToList();
            return Json(dataList, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetAllProduct()
        {
            
            var dataList = (from prd in db.Products.Include("ProductList").ToList()
                            where prd.QuantityInStore > 0
                            select new
                            {
                                ProductId = prd.Id,
                                //CategoryId = prd.CategoryId,
                                Name = prd.ProductList.ProductName,
                                CategoryName = prd.ProductName,
                                PurchasePrice = prd.PurchasePrice,
                                SellingPrice= prd.SellingPrice,
                            }).ToList();


            return Json(dataList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveInvoiceSale(Sale sale, List<SalesDetail> salesDetails, Customer customer)
        {
            AppHelper.ReturnMessage retMessage = new AppHelper.ReturnMessage();
            retMessage.IsSuccess = true;

            foreach (var item in salesDetails)
            {
                sale.SalesDetails.Add(new SalesDetail { ProductId = item.ProductId, UnitPrice = item.UnitPrice, Quantity = item.Quantity, LineTotal = item.LineTotal });
                sale.OrderDate= DateTime.Now;   
                sale.CreatedOn= DateTime.Now;
                sale.TotalAmout = sale.TotalAmout+item.LineTotal;
                sale.CustomerAddress= customer.Address;
                sale.CustomerName=customer.FirstName +" "+customer.LastName;
                sale.CustomerTin = customer.TIN;
                sale.SaleType = "Cash Sales";
                //sale.PaymentMethod = sale.PaymentMethod;
                var prd = db.Products.Where(x => x.Id == item.ProductId && x.QuantityInStore > 0).FirstOrDefault();
                prd.QuantityInStore = prd.QuantityInStore - item.Quantity;
                db.Entry(prd).State = EntityState.Modified;
            }
            db.Sales.Add(sale);
            retMessage.Messagae = "Save Success!";
            try
            {
                db.SaveChanges();
            }
            catch (Exception)
            {
                retMessage.IsSuccess = false;
            }

            return Json(retMessage, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetAllSales()
        {
            
            var dataList = db.Sales.ToList();
            var modefiedData = dataList.Select(x => new
            {
                SalesId = x.SalesId,
                OrderNo = x.OrderNo,
                CustomerName = x.CustomerName,
                CustomerPhone = x.CustomerPhone,
                CustomerAddress = x.CustomerAddress,
                OrderDate = x.OrderDate,
                TotalAmout = x.TotalAmout
            }).ToList();
            return Json(modefiedData, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetInvoiceBySalesId(int salesId)
        {
            
            List<Sale> dataList = (from sd in db.SalesDetails.ToList()
                                   join s in db.Sales on sd.SalesId equals s.SalesId
                                   where sd.SalesId == salesId
                                   select new Sale
                                   {
                                       SalesId = (int)sd.SalesId,
                                       OrderNo = s.OrderNo,
                                       CustomerName = s.CustomerName,
                                       CustomerPhone = s.CustomerPhone,
                                       CustomerAddress = s.CustomerAddress,
                                       OrderDate = s.OrderDate,
                                       PaymentMethod = s.PaymentMethod,
                                       TotalAmout = s.TotalAmout,
                                       SalesDetailId = sd.SalesDetailId,
                                       ProductId = sd.ProductId,
                                       UnitPrice = sd.UnitPrice,
                                       Subtotal = s.Subtotal,
                                       Quantity = sd.Quantity,
                                       LineTotal = sd.LineTotal,
                                   }).ToList();
            return Json(dataList, JsonRequestBehavior.AllowGet);
        }
        // DeleteSale
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteSale(int id)
        {
            if (ModelState.IsValid)
            {
                var sale = await db.Sales.FindAsync(id);
                db.Sales.Remove(sale);
                await db.SaveChangesAsync();
                TempData["Message"] = "sale has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete sale, please try again!";
            }
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
