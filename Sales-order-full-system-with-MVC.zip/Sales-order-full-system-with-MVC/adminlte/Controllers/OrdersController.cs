﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using adminlte.Data;
using adminlte.Models;
using adminlte.Helpers;
using adminlte.Models.Orders;

namespace adminlte.Controllers
{
    [RolesAuthorize]
    public class OrdersController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Orders
        public async Task<ActionResult> Index()
        {
            var orders = db.OrderMasters;
            return View(await orders.ToListAsync());
        }

        // GET: Orders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order =  db.Orders.Where(x=>x.OrderId==id).Include(c=>c.Customer).Include(p=>p.Product).FirstOrDefault();
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }
        public ActionResult CreateOrder()
        {
            var lastseq = db.OrderMasters.OrderByDescending(x => x.OrderId).Select(s=>s.OrderId).FirstOrDefault();
            if (lastseq == 0) lastseq = 1;
            else lastseq = lastseq + 1;
            ViewBag.InvoiceNum ="SO"+ DateTime.Now.ToString("yyyy")+ lastseq;
            ViewBag.ProductId = new SelectList(db.Products, "Id", "ProductName");
            return View();
        }
        [HttpGet]
        public JsonResult GetAllCustomers()
        {

            var dataList = db.Customers.ToList();
            return Json(dataList, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult GetAllProduct()
        {

            var dataList = (from prd in db.Products.Include("Category").ToList()
                            join stk in db.Stocks on prd.Id equals stk.ProductId
                            where stk.Quantity > 0
                            select new
                            {
                                ProductId = prd.Id,
                                //CategoryId = prd.CategoryId,
                                Name = prd.ProductName,
                                //CategoryName = prd.Category.CategoryName,
                                PurchasePrice = stk.PurchasePrice,
                                SellingPrice = stk.SellingPrice,
                            }).ToList();


            return Json(dataList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveInvoiceOrder(OrderMaster order, List<OrderDetails> orderDetails, Customer customer)
        {
            AppHelper.ReturnMessage retMessage = new AppHelper.ReturnMessage();
            retMessage.IsSuccess = true;

            foreach (var item in orderDetails)
            {
                order.OrderDetails.Add(new OrderDetails { ProductId = item.ProductId, UnitPrice = item.UnitPrice, Quantity = item.Quantity, LineTotal = item.LineTotal, UpdatedBy = User.Identity.Name, UpdatedOn = DateTime.Now });
                order.OrderDate = DateTime.Now;
                order.UpdatedOn = DateTime.Now;
                order.UpdatedBy = User.Identity.Name;
                order.TotalAmount = order.TotalAmount + item.LineTotal;
                order.CustomerAddress = customer.Address;
                order.CustomerName = customer.FirstName + " " + customer.LastName;
                order.CustomerTIN = customer.TIN;
                order.Remainpayment = order.TotalAmount - order.AdvancedPayment;
                order.OrderStatus = adminlte.Helpers.OrderStatus.Open.ToString();
                //sale.PaymentMethod = sale.PaymentMethod;
                var prd = db.Products.Where(x => x.Id == item.ProductId && x.QuantityInStore > 0).FirstOrDefault();
                prd.QuantityInStore = prd.QuantityInStore - item.Quantity;
                db.Entry(prd).State = EntityState.Modified;
            }
            db.OrderMasters.Add(order);
            retMessage.Messagae = "Save Success!";
            try
            {
                db.SaveChanges();
            }
            catch (Exception)
            {
                retMessage.IsSuccess = false;
            }

            return Json(retMessage, JsonRequestBehavior.AllowGet);
        }
        // GET: Orders/Create
        public ActionResult Create()
        {
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "FirstName");
            ViewBag.ProductId = new SelectList(db.Products, "Id", "ProductName");
            return View();
        }

        // POST: Orders/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]//GrandTotal
        public async Task<ActionResult> Create([Bind(Include = "OrderId,OrderDesc,OrderDate,ExpectedDelvDate,OrderStatus,CustomerId,ProductId,Quantity,UnitPrice,AdvancedPayment")] Order order)
        {
            if (ModelState.IsValid)
            {
                order.TotalAmount = order.UnitPrice * order.Quantity;
                order.TaxAmount = (order.TotalAmount *15) / 100;
                order.SubTotal=order.TotalAmount- order.TaxAmount;
                order.Remainpayment = order.TotalAmount-order.AdvancedPayment;

                order.UpdatedBy = "Admin";
                order.UpdatedOn= DateTime.Now;  
                db.Orders.Add(order);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "FirstName", order.CustomerId);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "ProductName", order.ProductId);
            return View(order);
        }

        // GET: Orders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderMaster order =  db.OrderMasters.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        // POST: Orders/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(OrderMaster order)
        {
            if (ModelState.IsValid)
            {
                var _order = db.OrderMasters.Find(order.OrderId);
                _order.ExpectedDelvDate = order.ExpectedDelvDate;
                _order.Remainpayment = _order.TotalAmount - order.AdvancedPayment;
                _order.OrderStatus = order.OrderStatus;
                _order.UpdatedBy = User.Identity.Name;
                _order.UpdatedOn = DateTime.Now;
                _order.AdvancedPayment = order.AdvancedPayment;
                db.Entry(_order).State = EntityState.Modified;
                await db.SaveChangesAsync();
                if(_order.OrderStatus== "Completed")
                {
                    Sale sale=new Sale();
                    sale.OrderDate = _order.OrderDate;
                    sale.CreatedOn = DateTime.Now;
                    sale.TotalAmout = _order.TotalAmount;
                    sale.CustomerAddress = _order.CustomerAddress;
                    sale.CustomerName = _order.CustomerName;
                    sale.CustomerTin = _order.CustomerTIN;
                    sale.SaleType = "Order Sales";
                    sale.OrderNo = _order.OrderNumber;
                    sale.PaymentMethod = _order.PaymentMethod;
                    sale.TotalAmout=_order.TotalAmount;
                    sale.CreatedBy = User.Identity.Name;
                    db.Sales.Add(sale);
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            return View(order);
        }

        // GET: Orders/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = await db.Orders.FindAsync(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        // POST: Orders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Order order = await db.Orders.FindAsync(id);
            db.Orders.Remove(order);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        [RolesAuthorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteOrder(int id)
        {
            if (ModelState.IsValid)
            {
                var order = await db.OrderMasters.FindAsync(id);
                db.OrderMasters.Remove(order);
                //var orderdetail = await db.OrderDetails.FindAsync(id);
                //db.OrderDetails.Remove(orderdetail);
                await db.SaveChangesAsync();
                TempData["Message"] = "order has been Deleted!";
            }
            else
            {
                TempData["Message"] = "Couldn't delete order, please try again!";
            }
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
