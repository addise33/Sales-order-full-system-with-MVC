﻿using adminlte.Data;
using adminlte.Helpers;
using adminlte.Models;
using adminlte.Models.ViewModel;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Web;
using System.Web.Mvc;
using System.Xml.Linq;
using static adminlte.Helpers.AppHelper;
using System.Drawing;
using Newtonsoft.Json.Linq;
using System.Reflection;
using System.Globalization;

namespace adminlte.Controllers
{
    [RolesAuthorize]
    public class DashboardController : Controller
    {
        private AppDbContext db = new AppDbContext();
        // GET: Dashboard
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Dashboard()
        {
            double totalcost = 0;
            //var groups = db.Sales.ToList()
            //    .GroupBy(p => p.CreatedOn.Day + "-" + p.CreatedOn.ToString("MMM"))
            //     .Select(g => new { name = g.Key, count = g.Sum(x => x.TotalAmout) });
            //ViewBag.Data = JsonConvert.SerializeObject(groups.Select(prop => new {
            //    label =prop.name,
            //    y = prop.count
            //}).ToList());
            //var order = db.OrderMasters.ToList()
            //         .GroupBy(p => p.OrderDate.Day + "-" + p.OrderDate.ToString("MMM"))
            //          .Select(g => new { name = g.Key, count = g.Sum(x => x.TotalAmount) });
            //ViewBag.Order = JsonConvert.SerializeObject(order.Select(prop => new {
            //    label = prop.name,
            //    y = prop.count
            //}).ToList());
            DateTime date = DateTime.Now.AddDays(-30);
            ViewBag.TotalRevenue = db.Sales.Where(x => x.CreatedOn > date).Select(s=>s.TotalAmout).Sum();
            double TotalPurchase=db.Products.Where(x => x.UpdateOn > date).Select(s => s.TotalPrice).Sum();
            List<Sale> products = db.Sales.Where(x => x.CreatedOn > date).ToList();
            foreach (var item in products)
            {
                List<SalesDetail> details=db.SalesDetails.Where(x=>x.SalesId==item.SalesId).ToList();
                foreach (var prod in details)
                {
                    var calc = double.Parse(db.Products.Where(p => p.Id == prod.ProductId).Select(s => s.PurchasePrice).FirstOrDefault().ToString());
                    totalcost = totalcost + prod.Quantity * calc;
                }
            }
            ViewBag.TotalCost=totalcost;
            ViewBag.TotalProfit = db.Sales.Where(x => x.CreatedOn > date).Select(s=>s.TotalAmout).Sum()- totalcost;
            var outofstocks = db.Stocks.Where(o => o.Quantity < 1).Include(p => p.Product).ToList();
            Session["OutStocks"] = outofstocks;

            var moneycolledtedList = db.Sales.ToList()
                .GroupBy(p => p.PaymentMethod)
                 .Select(g => new { name = g.Key, count = g.Sum(x => x.TotalAmout) });
            var tmpContainer = new List<MoneyCollectedBy>();

            foreach (var item in moneycolledtedList)
            {
                if (item.name == "Bank Transfer") ViewBag.Bank = item.count;
                if (item.name == "Tele Birr") ViewBag.Tele = item.count;
                if (item.name == "Cash") ViewBag.Cash = item.count;
            }

            var productsgroup = db.Products.Include(n=>n.ProductList).ToList()
                .GroupBy(p => p.ProductList.ProductName)
                 .Select(g => new { name = g.Key, count = g.Sum(x => x.QuantityInStore) });
             
            ViewBag.Products = JsonConvert.SerializeObject(productsgroup.Select(prop => new {
                Label = prop.name,
                y = prop.count,
                name=prop.name
            }).ToList());



            var query = db.Products.Include(n => n.ProductList).ToList()
                .GroupBy(p => p.ProductList.ProductName)
                 .Select(g => new { Name = g.Key, OrdersCount = g.Sum(x => x.QuantityInStore) });

            List<PieChart> List = new List<PieChart>();

            int i = 0;
           
            foreach (var row in query)
            {
                PieChart pie = new PieChart();
                pie.label = row.Name;
                pie.value = row.OrdersCount;
                System.Threading.Thread.Sleep(500);
                Random rnd = new Random();
                Color randomColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));

                pie.color = "#"+randomColor.Name;

                List.Add(pie);
                i++;
            }


            //string output = JsonConvert.SerializeObject(List);
            //ViewBag.Output = output;
            ViewBag.output = JsonConvert.SerializeObject(query.Select(prop => new {
                label = prop.Name,
                Y = prop.OrdersCount,
            }).ToList());
           
            return View();

 
        }
        public ActionResult outofstock()
        {
            var orders = db.Stocks.Where(o => o.Quantity <1).ToList();
            return Json(orders.Count(), JsonRequestBehavior.AllowGet);

        }
        public ActionResult TotalOrders()
        {
            var orders = db.OrderMasters.Where(o=>o.OrderStatus!="Completed").ToList();
            return Json(orders.Count(), JsonRequestBehavior.AllowGet);
        }
        public ActionResult TotalPurchase()
        {
            DateTime date = DateTime.Now.AddDays(-30);
            var purchase = db.Products.Where(x => x.UpdateOn > date).Select(s => s.TotalPrice).Sum();
            string money = string.Format("{0:c}", purchase).Replace('$', ' '); 
            return Json(money + " ETB", JsonRequestBehavior.AllowGet);
        }
        public ActionResult TotalSale()
        {
            DateTime date = DateTime.Now.AddDays(-30);
            var sales = db.Sales.Where(x=>x.CreatedOn> date).Select(s=>s.TotalAmout).Sum();
            string money = string.Format("{0:c}", sales).Replace('$', ' ');
            return Json(money + " ETB", JsonRequestBehavior.AllowGet);
        }  
        public ActionResult TotalUsers()
        {
            var orders = db.users.Where(u => u.Status == "Active").ToList();
            return Json(orders.Count(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult SalesReport()
        {
            List<Sale> stocks = new List<Sale>();
            ReportChart model = new ReportChart();
            List<string> title = new List<string>();
            List<string> totalAmount = new List<string>();
            var groups = db.Sales.ToList()
                  .GroupBy(p => p.CreatedOn.Day + "-" + p.CreatedOn.ToString("MMM"))
                   .Select(g => new { name = g.Key, count = g.Count() });
            foreach (var item in groups)
            {
                totalAmount.Add(item.count.ToString());
                title.Add(item.name.ToString());
            }
            model.Title = title;
            model.TotalAmount = totalAmount;
            return Json(groups, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Dashboardv2()
        {
            return View();
        }
        public FileContentResult UserPhotos()
        {
            if (User.Identity.IsAuthenticated)
            {
                string userId = User.Identity.Name;
                var user = db.users.Where(x => x.Userid == userId).FirstOrDefault();
                if (user == null)
                {
                    string fileName = HttpContext.Server.MapPath(@"~/Images/noImg.png");

                    byte[] imageData = null;
                    FileInfo fileInfo = new FileInfo(fileName);
                    long imageFileLength = fileInfo.Length;
                    FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    imageData = br.ReadBytes((int)imageFileLength);

                    return File(imageData, "image/png");

                }
                // to get the user details to load user Image    
                var userImage = db.users.Where(x => x.Userid == userId).FirstOrDefault();
                if(userImage.UserPhoto == null)
                {
                    string fileName = HttpContext.Server.MapPath(@"~/Images/noImg.png");

                    byte[] imageData = null;
                    FileInfo fileInfo = new FileInfo(fileName);
                    long imageFileLength = fileInfo.Length;
                    FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    imageData = br.ReadBytes((int)imageFileLength);

                    return File(imageData, "image/png");
                }
                return new FileContentResult(userImage.UserPhoto, "image/jpeg");
            }
            else
            {
                string fileName = HttpContext.Server.MapPath(@"~/Images/noImg.png");

                byte[] imageData = null;
                FileInfo fileInfo = new FileInfo(fileName);
                long imageFileLength = fileInfo.Length;
                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                imageData = br.ReadBytes((int)imageFileLength);
                return File(imageData, "image/png");

            }
        }
        public JsonResult SaleReport()
        {
            List<Sale> stocks = new List<Sale>();
            ReportChart model = new ReportChart();
            List<string> title = new List<string>();
            List<string> totalAmount = new List<string>();
            var groups = db.Sales.ToList()
                  .GroupBy(p => p.CreatedOn.Day + "-" + p.CreatedOn.ToString("MMM"))
                   .Select(g => new { name = g.Key, count = g.Sum(x => x.TotalAmout) });
            foreach (var item in groups)
            {
                totalAmount.Add(item.count.ToString());
                title.Add(item.name.ToString());
            }
            model.Title = title;
            model.TotalAmount = totalAmount;
            return Json(model, JsonRequestBehavior.AllowGet);
        }
        public JsonResult OrderReport()
        {
            List<Sale> stocks = new List<Sale>();
            ReportChart model = new ReportChart();
            List<string> title = new List<string>();
            List<string> totalAmount = new List<string>();
            var groups = db.OrderMasters.ToList()
                  .GroupBy(p => p.OrderDate.Day + "-" + p.OrderDate.ToString("MMM"))
                   .Select(g => new { name = g.Key, count = g.Sum(x => x.TotalAmount) });
            foreach (var item in groups)
            {
                totalAmount.Add(item.count.ToString());
                title.Add(item.name.ToString());
            }
            model.Title = title;
            model.TotalAmount = totalAmount;
            return Json(model, JsonRequestBehavior.AllowGet);
        }
        //public JsonResult StockReport()
        //{

        //    var productsgroup = db.Products.Include(n => n.ProductList).ToList()
        //        .GroupBy(p => p.ProductList.ProductName)
        //         .Select(g => new { name = g.Key, count = g.Sum(x => x.QuantityInStore) });

        //    List<Sale> stocks = new List<Sale>();
        //    PieChart model = new PieChart();
        //    List<string> color = new List<string>();
        //    List<string> bgcolor = new List<string>();
        //    List<string> label = new List<string>();
        //    List<string> value = new List<string>();
        //    var groups = db.Products.ToList()
        //          .GroupBy(p => p.ProductList.ProductName)
        //           .Select(g => new { name = g.Key, count = g.Sum(x => x.QuantityInStore) });
        //    foreach (var item in groups)
        //    {
        //        value.Add(item.count.ToString());
        //        value.Add(Color.Red.ToString());
        //        value.Add(Color.Red.ToString());
        //        label.Add(item.name.ToString());
        //    }
        //    model.label = label;
        //    model.value = value;
        //    return Json(model, JsonRequestBehavior.AllowGet);
        //}
        public ActionResult GetData()
        {

            var query = db.Products.Include(n => n.ProductList).ToList()
                .GroupBy(p => p.ProductList.ProductName)
                 .Select(g => new { Name = g.Key, OrdersCount = g.Sum(x => x.QuantityInStore) });

            List<PieChart> List = new List<PieChart>();

            int i = 0;
            foreach (var row in query)
            {
                PieChart pie = new PieChart();
                pie.label = row.Name;
                pie.value = row.OrdersCount;
                System.Threading.Thread.Sleep(500);

                Random randomGen = new Random();
                KnownColor[] names = (KnownColor[])Enum.GetValues(typeof(KnownColor));
                KnownColor randomColorName = names[randomGen.Next(names.Length)];
                Color randomColor = Color.FromKnownColor(randomColorName);

                pie.color = randomColor.Name;

                List.Add(pie);
                i++;
            }
            string output = JsonConvert.SerializeObject(List);
            return new JsonResult
            {
                Data = new
                {
                    success = output,
                    message = "Success",
                },
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };

        }

    }
}
