﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class RoleName
    {
        public const string AdminRoleName = "Admin";
        public const string SuperUserRoleName = "SuperUser";
        public const string UserManagerRoleName = "User";
        public const string CashierRoleName = "Cashier";
    }
}

        