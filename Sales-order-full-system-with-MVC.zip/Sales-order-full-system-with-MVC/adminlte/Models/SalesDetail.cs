﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class SalesDetail
    {
        [Key]
        public int SalesDetailId { get; set; }
        public int SalesId { get; set; }
        public Sale Sale { get; set; }
        public int ProductId { get; set; }
        public Product Product { get; set; }
        public Double UnitPrice { get; set; }
        public int Quantity { get; set; }
        public Double LineTotal { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<DateTime>  CreatedOn { get; set; }
        public int Status { get; set; }
    }
}