﻿using adminlte.Migrations;
using adminlte.Models.Orders;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class Credit: CommonCols
    {
        [Key]
        public int Id { get; set; }
        [Display(Name ="Creadit NO CR#")]
        public string CreditNo { get; set; }
        [Display(Name = "Credit Description")]
        public string CreditDescription { get; set; }
        [Display(Name = "Credit Date")]
        public DateTime CreditDate { get; set; }
        public int CustomerID { get; set; }
        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }
        [Display(Name = "Customer Address")]
        public string CustomerAddress { get; set; }
        [Display(Name = "Customer TIN")]
        public string CustomerTIN { get; set; }
        [Display(Name = "Credit Category")]
        public string CreditCategory { get; set; }
        [Display(Name = "Payment Method")]
        public string PaymentMethod { get; set; }
        [Display(Name = "Total Amount")]
        public Double TotalAmount { get; set; }
        [Display(Name = "Advanced Payment")]
        public Double AdvancedPayment { get; set; }
        [Display(Name = "Remaining Payment")]
        public Double RemainingPayment { get; set; }
        [Display(Name = "Payment Due")]
        public DateTime PaymentDue { get; set; }
        public string Status { get; set; }
        public ICollection<CreditDetails> CreditDetails { get; set; }
        public Credit()
        {
            CreditDetails = new Collection<CreditDetails>();
        }
    }
}