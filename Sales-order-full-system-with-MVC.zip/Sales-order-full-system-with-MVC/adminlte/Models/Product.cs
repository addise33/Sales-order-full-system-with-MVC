﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Display(Name = "Product Desc")]
        public string ProductName { get; set; }
        [Display(Name = "Serial No")]
        public string SerialNo { get; set; }
      
        public Nullable<int> ProductListId { get; set; }
        [Display(Name = "Product")]
        public ProductList ProductList { get; set; }
        public int SupplierID { get; set; }
        [Display(Name = "Supplier")]
        public Supplier Supplier { get; set; }
        [Display(Name = "Purchase Price")]
        public Double PurchasePrice { get; set; }
        [Display(Name = "Selling Price")]
        public Double SellingPrice { get; set; }
        [Display(Name = "Quantity")]
        public int QuantityInStore { get; set; }
        [Display(Name = "Quantity In Order")]
        public int QuantityInOrder { get; set; }
        [Display(Name = "Total Price")]
        public Double TotalPrice { get; set; }
        public Nullable<int> BatchId { get; set; }
        public Batch Batch { get; set; }
        [Display(Name = "Update By")]
        public string UpdateBy { get; set; }
        [Display(Name = "Update On")]
        public DateTime UpdateOn { get; set; }
    }
}