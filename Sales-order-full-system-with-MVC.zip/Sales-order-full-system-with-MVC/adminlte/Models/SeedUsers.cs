﻿using adminlte.Data;
using adminlte.Helpers;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class SeedUsers
    {
        public static void Seed(AppDbContext context)
        {
            context.users.AddOrUpdate(x => x.Userid,
                new users()
                {
                    Userid = "Admin",
                    Firstname = "Admin",
                    Lastname = "Admin",
                    Usertype = "Admin",
                    Password = Processor.MD5("Admin"),
                    Status = "Active",
                    EmailAddress = "",
                    Createdby = "Auto Created",
                    Createdon = DateTime.Now,
                    LastModifiedBy = "",
                    Lastmodifiedon = DateTime.Now,
                    UserPhoto = null,
                });
        }
        //protected static void Seed(ApplicationDbContext context)
        //{
        //    var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
        //    var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));

        //    if (!roleManager.RoleExists("Customer"))
        //    {
        //        var roleresult = roleManager.Create(new IdentityRole("Customer"));
        //    }
        //    if (!roleManager.RoleExists("Manager"))
        //    {
        //        var roleresult = roleManager.Create(new IdentityRole("Manager"));
        //    }

        //    string userName = "jimmymgr01";
        //    string password = "jimmymgr01";
        //    ApplicationUser user = userManager.FindByName(userName);
        //    if (user == null)
        //    {
        //        user = new ApplicationUser()
        //        {
        //            UserName = userName
        //        };

        //        IdentityResult userResult = userManager.Create(user, password);
        //        if (userResult.Succeeded)
        //        {
        //            var result = userManager.AddToRole(user.Id, "Manager");
        //        }
        //    }
        //}
    }
}