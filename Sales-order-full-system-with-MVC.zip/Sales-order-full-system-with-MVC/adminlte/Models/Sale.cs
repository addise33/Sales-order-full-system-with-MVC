﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class Sale
    {
        [Key]
        public int SalesId { get; set; }
        public string OrderNo { get; set; }
        public string CustomerName { get; set; }
        public string CustomerPhone { get; set; }
        public string CustomerTin { get; set; }
        public string CustomerAddress { get; set; }
        public Nullable<DateTime> OrderDate { get; set; }
        public string PaymentMethod { get; set; }
        public Double TotalAmout { get; set; }
        public string SaleType { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int Status { get; set; }
        public ICollection<SalesDetail> SalesDetails { get; set; }
        public Sale()
        {
            SalesDetails = new Collection<SalesDetail>();
        }
        [NotMapped]
        public int SalesDetailId { get; set; }
        [NotMapped]
        public Nullable<int> ProductId { get; set; }
        [NotMapped]
        public Nullable<double> UnitPrice { get; set; }
        [NotMapped]
        public Nullable<int> Quantity { get; set; }
        [NotMapped]
        public Nullable<double> LineTotal { get; set; }
        [NotMapped]
        public Nullable<double> Subtotal { get; set; }
    }
}