﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class Supplier
    {
        [Key]
        public int SupplierId { get; set; }
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }
        [Display(Name = "Supplier Name")]
        public string SupplierName { get; set; }
        public string Adress { get; set; }
        [Display(Name = "Phone Number")]
        [Phone]
        public string PhoneNo { get; set; }
        [Display(Name = "Email Address")]
        [EmailAddress]
        public string Email { get; set; }
        [Display(Name = "Updated By")]
        public string Updated_by { get; set; }
        [Display(Name = "Updated On")]
        public DateTime Updated_on { get; set; }
    }
}