﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class MaintenancendService: CommonCols
    {

        public int Id { get; set; }
        [Display(Name = "Device Name")]
        public string DeviceName { get; set; }
        [Display(Name = "Serial Number")]
        public string SerialNumber { get; set; }
        [Display(Name = "Device Detail")]
        public string DeviceDetail { get; set; }
        [Display(Name = "Maitenance Description")]
        public string MaitenanceDescription { get; set; }
        public int CustomerID { get; set; }
        public Customer Customer { get; set; }  
        public double payment { get; set; }
        [Display(Name = "Advanced payment")]
        public double Advancedpayment { get; set; }
        [Display(Name = "Remaining payment")]
        public double Remainingpayment { get; set; }
        [Display(Name = "Return Date")]
        public DateTime ReturnDate { get; set; }
        public string Remarks { get; set; }
    }
}