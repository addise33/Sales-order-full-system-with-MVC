﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class LoginModel
    {
        public String username { get; set; }
        public String Password { get; set; }
    }
}