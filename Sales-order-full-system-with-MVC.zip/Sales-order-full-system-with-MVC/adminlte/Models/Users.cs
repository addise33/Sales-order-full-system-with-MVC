﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    [Table(name: "Users")]
    public class users
    {
        [Key]
        public int Sequence { get; set; }
        [Required]
        [Display(Name = "User Name")]
        public string Userid { get; set; }
        [Required]
        [Display(Name = "First Name")]
        public string Firstname { get; set; }
        [Required]
        [Display(Name = "Last Name")]
        public string Lastname { get; set; }
        [Required]
        [Display(Name = "User Type")]
        public string Usertype { get; set; }
        public string Password { get; set; }
        public string Status { get; set; }
        [Display(Name = "User Photo")]
        public byte[] UserPhoto { get; set; }

        [Display(Name = "Email Address")]
        public string EmailAddress { get; set; }
        public string Createdby { get; set; }
        public Nullable<DateTime> Createdon { get; set; }
        public string LastModifiedBy { get; set; }
        public Nullable<DateTime> Lastmodifiedon { get; set; }
   
    }
}