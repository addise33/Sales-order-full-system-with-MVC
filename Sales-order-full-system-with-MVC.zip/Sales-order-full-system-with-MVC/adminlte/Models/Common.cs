﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class CommonCols
    {
        public string UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}