﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace adminlte.Models.ViewModel
{
    public class SaleDetailsView
    {
        public Sale Sale { get; set; }
        public IEnumerable<SalesDetail> SalesDetail { get; set; } 
        public string AmountInWords { get; set; }   
    }
}