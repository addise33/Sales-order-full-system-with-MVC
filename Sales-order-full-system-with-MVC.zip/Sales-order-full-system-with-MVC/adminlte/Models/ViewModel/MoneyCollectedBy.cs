﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace adminlte.Models.ViewModel
{
    public class MoneyCollectedBy
    {
        public string type { get; set; }
        public Double amount { get; set; }
    }
}