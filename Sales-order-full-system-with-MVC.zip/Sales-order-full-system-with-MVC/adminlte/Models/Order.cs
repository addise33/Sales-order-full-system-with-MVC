﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace adminlte.Models
{
    public class Order: CommonCols
    {
        public int OrderId { get; set; }
        [Display(Name = "Order Desc")]
        public string OrderDesc { get; set; }
        [Display(Name = "Order Date")]
        public DateTime OrderDate { get; set; }
        [Display(Name = "Expected Delivery Date")]
        public DateTime ExpectedDelvDate { get; set; }
        [Display(Name = "Order Status")]
        public string OrderStatus { get; set; }
        [Display(Name = "Customer")]
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }
        [Display(Name = "Product")]
        public int ProductId { get; set; }
        [Display(Name = "Product")]
        public Product Product { get; set; }
        public int Quantity { get; set; }
        [Display(Name = "Unit Price")]
        public Double UnitPrice { get; set; }
        [Display(Name = "Total Amount")]
        public Double TotalAmount { get; set; }
        [Display(Name = "Advanced Payment")]
        public Double AdvancedPayment { get; set; }
        [Display(Name = "Sub Total")]
        public Double SubTotal { get; set; }
        [Display(Name = "Tax Percentage")]
        public Double TaxPercentage { get; set; }
        [Display(Name = "Tax Amount")]
        public Double TaxAmount { get; set; }
        [Display(Name = "Remain payment")]
        public Double Remainpayment { get; set; }


    }
}