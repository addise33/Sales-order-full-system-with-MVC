﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection.Emit;
using System.Web;

namespace adminlte.Models
{
    public class Batch
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Batch Name")]
        public string BatchName { get; set;}
        [Display(Name = "Created By")]
        public string CreatedBy { get; set; }
        [Display(Name = "Created On")]
        public DateTime CreatedOn { get; set; }
    }
}