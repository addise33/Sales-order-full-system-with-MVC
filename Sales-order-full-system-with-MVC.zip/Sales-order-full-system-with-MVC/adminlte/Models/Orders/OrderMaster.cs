﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace adminlte.Models.Orders
{
    public class OrderMaster: CommonCols
    {
        [Key]
        public int OrderId { get; set; }
        [Display(Name = "Sale Order")]
        public string OrderNumber { get; set; }
        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }
        [Display(Name = "Customer Address")]
        public string CustomerAddress { get; set; }
        [Display(Name = "Customer TIN")]
        public string CustomerTIN { get; set; }
        [Display(Name = "Order Desc")]
        public string OrderDesc { get; set; }
        [Display(Name = "Order Date")]
        public DateTime OrderDate { get; set; }
        [Display(Name = "Expected Delivery Date")]
        public DateTime ExpectedDelvDate { get; set; }
        [Display(Name = "Order Status")]
        public string OrderStatus { get; set; }
        public string PaymentMethod { get; set; }
        [Display(Name = "Total Amount")]
        public Double TotalAmount { get; set; }
        [Display(Name = "Advanced Payment")]
        public Double AdvancedPayment { get; set; }
        [Display(Name = "Remain payment")]
        public Double Remainpayment { get; set; }
        public ICollection<OrderDetails> OrderDetails { get; set; }
        public OrderMaster()
        {
            OrderDetails = new Collection<OrderDetails>();
        }
    }
}