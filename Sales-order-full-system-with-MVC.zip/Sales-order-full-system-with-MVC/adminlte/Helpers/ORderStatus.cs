﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace adminlte.Helpers
{
    public enum OrderStatus
    {
        
        Open,
        WaitingPayment,
        Refunded,
        Completed,
        Cancelled,
        Declined,
        Disputed
    }
    public enum CreditStatus
    {

        Open,
        Completed,
        Cancelled,
        Declined,
    }

}