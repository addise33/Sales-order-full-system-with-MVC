﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace adminlte.Helpers
{
    public class DbReporting
    {
        public static SqlDataSource GetDataSource()
        {
            string connString = GetConnString();
            if (connString == null)
                return (SqlDataSource)null;
            return new SqlDataSource()
            {
                ConnectionString = connString
            };
        }
        private static string GetConnString() => ConfigurationManager.ConnectionStrings["DefaultConnection"]?.ConnectionString;
        public static SqlCommand GetCommand(string query)
        {
            string connString = GetConnString();
            SqlCommand command = (SqlCommand)null;
            if (connString != null)
            {
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = connString;
                command = new SqlCommand(query, connection);
                connection.Open();
            }
            return command;
        }
    }
}