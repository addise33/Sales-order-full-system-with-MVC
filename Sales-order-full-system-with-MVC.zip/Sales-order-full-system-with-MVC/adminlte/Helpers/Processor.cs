﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Security.Cryptography;
using System.Web;
using adminlte.Models;
using adminlte.Data;
using System.Configuration;
using System.Web.Security;

namespace adminlte.Helpers
{
    public class Processor
    {
        private static AppDbContext db = new AppDbContext();
        public static string MD5(string str)
        {
            return FormsAuthentication.HashPasswordForStoringInConfigFile(str, "md5");
        }
        public static void Sendpassword(string newpassword, string username)
        {
            string email = Getemailaddress(username);

            if (email != "" && email != null)
            {
                try
                {
                    string strsender = ConfigurationManager.AppSettings["sender"];
                    string strhost = ConfigurationManager.AppSettings["Host"];
                    string strpassword = ConfigurationManager.AppSettings["password"];
                    short strport = short.Parse(ConfigurationManager.AppSettings["Port"]);
                    var message = new MailMessage();
                    var client = new SmtpClient();
                    message.From = new MailAddress(strsender);
                    message.To.Add(email);
                    string fromAddress = strsender;
                    message.Body = "  Dear User <br /> Greetings!!<br /><br /> Your Hardship Allowance Portal password is reset to ";
                    message.Body += "<font color='SeaGreen'>" + newpassword.ToString().ToString() + "</font>";
                    message.Body += " please login to the page and change your password";
                    message.Body += " http://svhqoas01:88";
                    message.Body += "  <br />";
                    message.Body += "  <br />Best Regards";
                    message.IsBodyHtml = true;
                    message.Subject = "Hardship Allowance Portal Password!";
                    message.Priority = MailPriority.High;
                    client.Port = strport;
                    client.Host = strhost;
                    client.Credentials = new NetworkCredential(fromAddress, strpassword);
                    client.Send(message);
                    message.Dispose();
                    client.Dispose();
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            else
            {

            }
        }
        public static string GetRandomPassword(int length)
        {
            byte[] rgb = new byte[length];
            RNGCryptoServiceProvider rngCrypt = new RNGCryptoServiceProvider();
            rngCrypt.GetBytes(rgb);
            return Convert.ToBase64String(rgb);
        }
        public static string Getemailaddress(string username)
        {
            users user = db.users.Where(x => x.Userid == username).FirstOrDefault();
            return user.EmailAddress;
        }
    }
}